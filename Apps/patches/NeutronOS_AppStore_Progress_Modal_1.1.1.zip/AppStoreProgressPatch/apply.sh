#!/usr/bin/env bash
set -euo pipefail

ROOT="${HOME}/NeutronOS"
TARGET="$ROOT/qml/apps/appstore/Main.qml"
PAYLOAD="$(cd "$(dirname "$0")" && pwd)/payload/project/qml/apps/appstore/Main.qml"
BASE_SHA="ace2009c9f08a51732852a7615adc17603ce754db706527564d84cb6b8fbce2f"
NEW_SHA="97314c877bf9887f001ff9f60dbb4133e5ec06ec876bf9aeb080297f8ba13256"

die() { echo "ERROR: $*" >&2; exit 1; }
command -v sha256sum >/dev/null 2>&1 || die "sha256sum is required"
[ -f "$TARGET" ] || die "App Store Main.qml not found: $TARGET"
[ -f "$PAYLOAD" ] || die "Patch payload missing: $PAYLOAD"

CURRENT_SHA="$(sha256sum "$TARGET" | awk '{print $1}')"
PAYLOAD_SHA="$(sha256sum "$PAYLOAD" | awk '{print $1}')"
[ "$PAYLOAD_SHA" = "$NEW_SHA" ] || die "Patch payload hash mismatch"

if [ "$CURRENT_SHA" = "$NEW_SHA" ]; then
    echo "App Store progress modal is already installed."
elif [ "$CURRENT_SHA" = "$BASE_SHA" ]; then
    install -m 0644 "$PAYLOAD" "$TARGET"
    INSTALLED_SHA="$(sha256sum "$TARGET" | awk '{print $1}')"
    [ "$INSTALLED_SHA" = "$NEW_SHA" ] || die "Installed App Store QML failed verification"
    echo "App Store progress modal installed."
else
    echo "Expected base SHA: $BASE_SHA"
    echo "Current SHA:       $CURRENT_SHA"
    die "Live App Store Main.qml differs from the validated Reference Redesign v3 source. Refusing to overwrite it."
fi

sudo systemctl restart neutronos.service
systemctl is-active --quiet neutronos.service || die "neutronos.service did not return active"
echo "neutronos.service: active"
