import QtQuick 2.15
import QtQuick.Controls 2.15
import "../../components" as Shared

Item {
    id: root
    anchors.fill: parent
    focus: true

    property string appId: "appstore"
    property string appName: "App Store"
    property var appData: ({})
    property var activeUser: null
    property bool hostActive: true
    property bool developerModeEnabled: (typeof developerModeManager !== "undefined")
                                        ? developerModeManager.developerModeEnabled : false
    property var backend: (typeof appStoreManager !== "undefined") ? appStoreManager : null
    property var assetBackend: (typeof assetManager !== "undefined") ? assetManager : null
    property var securityBackend: (typeof securityCoreManager !== "undefined") ? securityCoreManager : null

    // Reference-app navigation contract:
    // 0 top tabs, 1 package list, 2 detail actions, 3 header menu.
    property int focusZone: 0
    property int tabIndex: 0
    property int packageIndex: 0
    property int actionIndex: 0
    property int screenshotIndex: 0
    readonly property real textScale: 1.40
    property var selectedFootprint: ({})
    property bool packageEngaged: false
    property var topTabs: ["Discover", "Updates", "Installed"]
    property var visiblePackages: []
    property string searchText: ""
    property string selectedFilter: "available"

    property bool keyboardOpen: false
    property string keyboardPurpose: ""
    property string keyboardBuffer: ""
    property bool confirmOpen: false
    property string confirmOperation: ""
    property bool repositoriesOpen: false
    property int repositoryIndex: 0
    property bool statusOpen: false
    property bool exitOpen: false
    property string toastText: ""
    property bool analysisOpen: false
    property int analysisActionIndex: 0
    property string analyzedPackagePath: ""

    readonly property bool securityProtected: securityBackend &&
                                                securityBackend.daemonOnline &&
                                                securityBackend.auditValid &&
                                                Number(securityBackend.threatLevel || 5) > 2
    readonly property bool repositoryConnected: backend ? backend.repositoryConnected : false

    readonly property color background: "#050711"
    readonly property color panel: "#d9162134"
    readonly property color panelStrong: "#f21a263c"
    readonly property color panelRaised: "#f01b2940"
    readonly property color border: "#4a688fae"
    readonly property color focusBlue: "#49c8ff"
    readonly property color cyan: "#7df9ff"
    readonly property color purple: "#c084fc"
    readonly property color success: "#35e68a"
    readonly property color warning: "#ffc857"
    readonly property color danger: "#ff4050"
    readonly property color textPrimary: "#f5fbff"
    readonly property color textSecondary: "#aebbd0"
    readonly property color textMuted: "#75869d"

    signal exitRequested()
    signal backgroundRequested()

    function normalizeAction(action) {
        var value = String(action || "").toLowerCase()
        if (value === "x" || value === "cross" || value === "accept" || value === "enter") return "primary"
        if (value === "o" || value === "circle" || value === "back" || value === "escape") return "cancel"
        if (value === "dpadup" || value === "up" || value === "leftstickup") return "up"
        if (value === "dpaddown" || value === "down" || value === "leftstickdown") return "down"
        if (value === "dpadleft" || value === "left" || value === "leftstickleft") return "left"
        if (value === "dpadright" || value === "right" || value === "leftstickright") return "right"
        if (value === "options" || value === "start" || value === "menu") return "start"
        if (value === "triangle" || value === "y") return "triangle"
        if (value === "square" || value === "xbox-x") return "square"
        if (value === "r3" || value === "rightstickclick") return "r3"
        if (value === "l1" || value === "leftshoulder") return "l1"
        if (value === "r1" || value === "rightshoulder") return "r1"
        return value
    }

    function tabName() {
        return String(topTabs[Math.max(0, Math.min(tabIndex, topTabs.length - 1))])
    }

    function refreshVisiblePackages() {
        if (!backend) {
            visiblePackages = []
            packageIndex = 0
            actionIndex = 0
            return
        }
        if (tabIndex === 1) selectedFilter = "updates"
        else if (tabIndex === 2) selectedFilter = "installed"
        else selectedFilter = "available"
        visiblePackages = backend.searchPackages(searchText, "All", selectedFilter)
        packageIndex = Math.max(0, Math.min(packageIndex, Math.max(0, visiblePackages.length - 1)))
        actionIndex = Math.max(0, Math.min(actionIndex, Math.max(0, packageActions(currentPackage()).length - 1)))
        if (packageList) packageList.positionViewAtIndex(packageIndex, ListView.Contain)
        refreshFootprint()
    }

    function selectTab(index) {
        tabIndex = Math.max(0, Math.min(index, topTabs.length - 1))
        packageIndex = 0
        actionIndex = 0
        screenshotIndex = 0
        packageEngaged = false
        refreshVisiblePackages()
    }

    function currentPackage() {
        if (!visiblePackages || visiblePackages.length === 0) return ({})
        return visiblePackages[Math.max(0, Math.min(packageIndex, visiblePackages.length - 1))]
    }

    function detailPackage() {
        return packageEngaged ? currentPackage() : ({})
    }

    function packageActions(item) {
        var actions = []
        if (!item || !item.id) return actions
        if (item.updateEligible || item.updateAvailable)
            actions.push({ id: "update", label: "UPDATE", tone: "warning" })
        else if (item.storeEligible && !item.installed)
            actions.push({ id: "install", label: "INSTALL", tone: "success" })
        if (item.installed && item.managed)
            actions.push({ id: "uninstall", label: "UNINSTALL", tone: "danger" })
        return actions
    }

    function permissionItems(item) {
        var result = []
        if (!item || !item.permissions) return result
        for (var i = 0; i < item.permissions.length; ++i) {
            var value = String(item.permissions[i] || "").trim()
            if (value.length && result.indexOf(value) < 0) result.push(value)
        }
        return result
    }

    function dependencyItems(item) {
        var result = []
        if (!item) return result
        var sources = [item.dependencies, item.debianDependencies]
        for (var s = 0; s < sources.length; ++s) {
            var list = sources[s]
            if (!list) continue
            for (var i = 0; i < list.length; ++i) {
                var value = String(list[i] || "").trim()
                if (value.length && result.indexOf(value) < 0) result.push(value)
            }
        }
        if (item.runtimeRequirements) {
            for (var r = 0; r < item.runtimeRequirements.length; ++r) {
                var requirement = item.runtimeRequirements[r]
                var label = requirement && requirement.type ? String(requirement.type) : "runtime requirement"
                if (result.indexOf(label) < 0) result.push(label)
            }
        }
        return result
    }

    function joinedOrFallback(values, fallback) {
        return values && values.length ? values.join("  •  ") : fallback
    }

    function compatibilityText(item) {
        if (!item || !item.id) return "Select an app to review compatibility"
        if (item.compatible) return "Compatible With This Device"
        var reasons = item.compatibilityReasons || []
        return reasons.length ? reasons.join(" • ") : "Not Compatible With This Device"
    }

    function packageSize(item) {
        if (!backend || !item || !item.id) return "—"
        var bytes = Number(item.sizeBytes || item.size || item.installedBytes || 0)
        return backend.formatBytes(bytes)
    }

    function refreshFootprint() {
        var item = detailPackage()
        selectedFootprint = (backend && item && item.id) ? backend.installFootprint(item.id) : ({})
    }

    function footprintText(key, fallback) {
        if (!backend || !selectedFootprint || selectedFootprint[key] === undefined) return fallback || "—"
        var bytes = Number(selectedFootprint[key] || 0)
        var missing = selectedFootprint.missingDependencies || []
        if (selectedFootprint.known === false && bytes <= 0 && missing.length > 0) return "Unavailable"
        return backend.formatBytes(bytes)
    }

    function diskImpactText() {
        if (!backend || !selectedFootprint || selectedFootprint.totalInstalledBytes === undefined) return "—"
        var prefix = selectedFootprint.diskEstimateLowerBound ? "≥ " : ""
        return prefix + backend.formatBytes(Number(selectedFootprint.totalInstalledBytes || 0))
    }

    function missingDependenciesText(item) {
        var declared = root.dependencyItems(item)
        var missing = selectedFootprint && selectedFootprint.missingDependencies ? selectedFootprint.missingDependencies : []
        var declaredText = root.joinedOrFallback(declared, "No additional dependencies declared")
        if (!item || !item.id) return declaredText
        if (missing && missing.length) return declaredText + "\nMissing on this device: " + missing.join("  •  ")
        return declaredText + "\nEverything required by this package is already present."
    }

    function primaryPackageAction(item) {
        var actions = packageActions(item)
        return actions.length ? actions[0] : ({})
    }

    function packagePillLabel(item) {
        if (!item || !item.id) return ""
        if (backend && backend.busy && String(backend.activePackageId) === String(item.id)) {
            if (backend.activeOperation === "update") return "UPDATING"
            if (backend.activeOperation === "install") return "INSTALLING"
            if (backend.activeOperation === "uninstall") return "REMOVING"
        }
        if (item.updateEligible || item.updateAvailable) return "UPDATE"
        if (item.installed) return "INSTALLED"
        return "INSTALL"
    }

    function packagePillTone(item) {
        var label = packagePillLabel(item)
        if (label === "UPDATE" || label === "UPDATING") return "warning"
        if (label === "REMOVING") return "danger"
        return "success"
    }

    function assetSource(value, fallbackId, kind) {
        var text = String(value || fallbackId || "")
        if (text.length === 0) text = "appstore"
        if (text.indexOf("http://") === 0 || text.indexOf("https://") === 0 ||
                text.indexOf("file://") === 0 || text.indexOf("qrc:/") === 0)
            return text
        if (text.indexOf("/") >= 0) return "file://" + text
        if (assetBackend) {
            var resolved = kind === "poster" ? assetBackend.appPoster(text) : assetBackend.appIcon(text)
            if (String(resolved || "").length > 0) return resolved
        }
        var directory = kind === "poster" ? "posters" : "icons"
        return Qt.resolvedUrl("../../../themes/Default/apps/" + directory + "/" + text + ".png")
    }

    function screenshotSource(item) {
        if (!item || !item.id) return assetSource("appstore", "appstore", "poster")
        if (!item.screenshots || item.screenshots.length === 0)
            return assetSource(item.poster || item.id, item.id, "poster")
        screenshotIndex = Math.max(0, Math.min(screenshotIndex, item.screenshots.length - 1))
        var source = String(item.screenshots[screenshotIndex])
        if (source.indexOf("http") === 0 || source.indexOf("file:") === 0) return source
        var repo = String(item.repositoryBaseUrl || "")
        return repo.length ? repo + "/" + source : source
    }

    function artworkSource(item) {
        if (!item || !item.id) return assetSource("appstore", "appstore", "poster")
        return assetSource(item.poster || item.id, item.id, "poster")
    }

    function screenshotAt(item, index) {
        if (!item || !item.id || !item.screenshots || index < 0 || index >= item.screenshots.length) return ""
        var source = String(item.screenshots[index] || "")
        if (source.indexOf("http://") === 0 || source.indexOf("https://") === 0 || source.indexOf("file:") === 0 || source.indexOf("qrc:/") === 0) return source
        var repo = String(item.repositoryBaseUrl || "")
        return repo.length ? repo + "/" + source : source
    }

    function openConfirmation(operation) {
        var item = detailPackage()
        if (!item || !item.id || (backend && backend.busy)) return
        confirmOperation = operation
        confirmOpen = true
    }

    function performConfirmedOperation() {
        var item = detailPackage()
        var started = false
        if (!backend || !item || !item.id) return
        if (confirmOperation === "install") started = backend.installPackage(item.id)
        else if (confirmOperation === "update") started = backend.updatePackage(item.id)
        else if (confirmOperation === "uninstall") started = backend.uninstallPackage(item.id)
        confirmOpen = false
        if (!started) {
            toastText = backend ? backend.statusMessage : "Operation could not start"
            statusOpen = true
        }
    }

    function activateAction() {
        var item = detailPackage()
        var action = primaryPackageAction(item)
        if (!action || !action.id) return
        actionIndex = 0
        openConfirmation(action.id)
    }

    function openKeyboard(purpose, initialText) {
        keyboardPurpose = purpose
        keyboardBuffer = String(initialText || "")
        keyboardOpen = true
        virtualKeyboard.openKeyboard()
    }

    function appendKeyboard(value) {
        if (value === "SPACE") value = " "
        keyboardBuffer += value
    }

    function finishKeyboard() {
        if (keyboardPurpose === "search") {
            searchText = keyboardBuffer
            packageEngaged = false
            refreshVisiblePackages()
        } else if (keyboardPurpose === "manual") {
            if (backend && keyboardBuffer.length > 0) {
                analyzedPackagePath = keyboardBuffer
                var analysis = backend.analyzeLocalPackage(keyboardBuffer)
                if (analysis && analysis.classification) {
                    analysisActionIndex = analysis.classification === "DANGEROUS" ? 1 : 0
                    analysisOpen = true
                } else {
                    toastText = backend.statusMessage
                    statusOpen = true
                }
            }
        } else if (keyboardPurpose === "repository") {
            var parts = keyboardBuffer.split("|")
            if (backend && parts.length >= 3) {
                if (!backend.addRepository(parts[0], parts[1], parts[2])) {
                    toastText = backend.statusMessage
                    statusOpen = true
                }
            }
        }
        keyboardOpen = false
        keyboardPurpose = ""
    }

    function handleControllerPressed(action) {
        if (!hostActive) return false
        var value = normalizeAction(action)

        if (keyboardOpen) {
            if (value === "cancel") { keyboardOpen = false; keyboardPurpose = "" }
            return true
        }
        if (analysisOpen) {
            if (value === "left") analysisActionIndex = Math.max(0, analysisActionIndex - 1)
            else if (value === "right") analysisActionIndex = Math.min(2, analysisActionIndex + 1)
            else if (value === "cancel") analysisOpen = false
            else if (value === "primary") {
                if (analysisActionIndex === 0) {
                    if (backend.lastSecurityAnalysis.classification !== "DANGEROUS") backend.installLocalPackage(analyzedPackagePath)
                } else if (analysisActionIndex === 1 && securityBackend) {
                    securityBackend.quarantineAppPackage(analyzedPackagePath)
                } else if (analysisActionIndex === 2) backend.removeAnalyzedPackage(analyzedPackagePath)
                analysisOpen = false
            }
            return true
        }
        if (statusOpen) { if (value === "primary" || value === "cancel") statusOpen = false; return true }
        if (backend && backend.busy &&
                (String(backend.activeOperation) === "install" || String(backend.activeOperation) === "update"))
            return true
        if (confirmOpen) {
            if (value === "primary") performConfirmedOperation()
            else if (value === "cancel") confirmOpen = false
            return true
        }
        if (exitOpen) return referenceExitModal.handleController(value)
        if (repositoriesOpen) {
            var repositories = backend ? backend.repositories : []
            if (value === "up") repositoryIndex = Math.max(0, repositoryIndex - 1)
            else if (value === "down") repositoryIndex = Math.min(Math.max(0, repositories.length - 1), repositoryIndex + 1)
            else if (value === "cancel" || value === "start") repositoriesOpen = false
            else if (value === "primary" && repositories.length) {
                var repository = repositories[repositoryIndex]
                backend.setRepositoryEnabled(repository.id, !repository.enabled)
            } else if (value === "square" && repositories.length && developerModeEnabled) {
                var selected = repositories[repositoryIndex]
                backend.setRepositoryTrusted(selected.id, !selected.trusted)
            } else if (value === "triangle" && developerModeEnabled) {
                openKeyboard("repository", "Custom Repository|https://raw.githubusercontent.com/OGDrNeutron/NeutronOS/main/Apps/index.json|trusted-key-id")
            } else if (value === "r1" && repositories.length && developerModeEnabled) {
                var removable = repositories[repositoryIndex]
                if (!backend.removeRepository(removable.id)) {
                    toastText = "The official repository cannot be removed."
                    statusOpen = true
                } else {
                    repositoryIndex = Math.max(0, Math.min(repositoryIndex, backend.repositories.length - 1))
                }
            }
            return true
        }

        if (value === "cancel") { exitOpen = true; referenceExitModal.openModal(root); return true }
        if (value === "start") { repositoriesOpen = true; repositoryIndex = 0; return true }
        if (value === "r3") { openKeyboard("search", searchText); return true }
        if (value === "triangle") {
            if (developerModeEnabled) openKeyboard("manual", backend.manualPackageDirectory() + "/")
            else { toastText = "Developer Mode is required for manual packages."; statusOpen = true }
            return true
        }
        if (value === "square") {
            selectTab(tabIndex === 1 ? 0 : 1)
            focusZone = 0
            return true
        }
        if (value === "l1" && packageEngaged) {
            var itemL = currentPackage()
            if (itemL.screenshots && itemL.screenshots.length) screenshotIndex = Math.max(0, screenshotIndex - 1)
            return true
        }
        if (value === "r1" && packageEngaged) {
            var itemR = currentPackage()
            if (itemR.screenshots && itemR.screenshots.length) screenshotIndex = Math.min(itemR.screenshots.length - 1, screenshotIndex + 1)
            return true
        }

        if (focusZone === 3) {
            if (value === "primary") { exitOpen = true; referenceExitModal.openModal(root) }
            else if (value === "down") focusZone = 0
            return true
        }

        if (focusZone === 0) {
            if (value === "left") selectTab(tabIndex - 1)
            else if (value === "right") selectTab(tabIndex + 1)
            else if (value === "up") focusZone = 3
            else if (value === "down" || value === "primary") {
                if (visiblePackages.length > 0) {
                    focusZone = 1
                    packageEngaged = true
                }
            }
            return true
        }

        if (focusZone === 1) {
            if (value === "up") {
                if (packageIndex > 0) packageIndex--
                else { focusZone = 0; packageEngaged = false }
            } else if (value === "down") {
                packageIndex = Math.min(Math.max(0, visiblePackages.length - 1), packageIndex + 1)
                packageEngaged = visiblePackages.length > 0
            } else if (value === "right" || value === "primary") {
                if (packageActions(currentPackage()).length > 0) {
                    focusZone = 2
                    actionIndex = 0
                }
            }
            packageList.positionViewAtIndex(packageIndex, ListView.Contain)
            refreshFootprint()
            return true
        }

        if (focusZone === 2) {
            if (value === "left" || value === "cancel") focusZone = 1
            else if (value === "primary") activateAction()
            return true
        }
        return true
    }

    function handleController(action) { return handleControllerPressed(action) }
    function handleControllerReleased(action) { return true }
    function prepareForUnload() { }

    Component.onCompleted: {
        forceActiveFocus()
        if (securityBackend && typeof securityBackend.refresh === "function") securityBackend.refresh()
        if (backend) backend.refreshCatalog()
        refreshVisiblePackages()
    }

    Connections {
        target: backend
        ignoreUnknownSignals: true
        function onCatalogChanged() { root.refreshVisiblePackages() }
        function onOperationFinished(packageId, operation, success, message) {
            root.toastText = message
            root.statusOpen = true
            root.refreshVisiblePackages()
        }
    }

    Rectangle { anchors.fill: parent; color: root.background }
    Image {
        anchors.fill: parent
        source: root.assetBackend ? root.assetBackend.themeFile("background.png")
                                  : Qt.resolvedUrl("../../../themes/Default/background.png")
        fillMode: Image.PreserveAspectCrop
        opacity: 0.20
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#92050711" }
            GradientStop { position: 0.55; color: "#42091422" }
            GradientStop { position: 1.0; color: "#c0050711" }
        }
    }

    Shared.ReferenceAppHeader {
        id: referenceHeader
        x: 18
        width: parent.width - 36
        anchors.top: parent.top
        z: 50
        appTitle: "App Store"
        primaryStatus: root.securityProtected ? "Secure" : "Attention"
        primaryTone: root.securityProtected ? "success" : "danger"
        secondaryStatus: root.repositoryConnected ? "Connected" : "Disconnected"
        secondaryTone: root.repositoryConnected ? "success" : "danger"
        attention: !root.securityProtected
        menuFocused: root.focusZone === 3 && !root.exitOpen
        onMenuRequested: { root.exitOpen = true; referenceExitModal.openModal(root) }
    }

    Shared.ReferenceAppFooter {
        id: referenceFooter
        x: 18
        width: parent.width - 36
        anchors.bottom: parent.bottom
        z: 50
    }

    Item {
        id: workspace
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: referenceHeader.bottom
        anchors.bottom: referenceFooter.top
        anchors.leftMargin: 18
        anchors.rightMargin: 18
        anchors.topMargin: 12
        anchors.bottomMargin: 12

        Rectangle {
            id: topTabBar
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            height: 54
            radius: 8
            color: "#E607101B"
            border.width: root.focusZone === 0 ? 2 : 1
            border.color: root.focusZone === 0 ? root.focusBlue : "#25313C"

            Row {
                anchors.centerIn: parent
                spacing: 30
                Repeater {
                    model: root.topTabs
                    Rectangle {
                        required property int index
                        required property string modelData
                        width: Math.max(170, topTabText.implicitWidth + 52)
                        height: 40
                        radius: 7
                        color: root.tabIndex === index ? "#16364D" : "transparent"
                        border.width: root.focusZone === 0 && root.tabIndex === index ? 2 : 0
                        border.color: root.focusBlue
                        Text {
                            id: topTabText
                            anchors.centerIn: parent
                            text: modelData.toUpperCase()
                            color: root.tabIndex === index ? root.textPrimary : root.textSecondary
                            font.pixelSize: Math.round(14 * root.textScale)
                            font.bold: true
                            font.letterSpacing: 1.3
                        }
                        MouseArea {
                            anchors.fill: parent
                            hoverEnabled: true
                            onEntered: root.selectTab(index)
                            onClicked: { root.selectTab(index); root.focusZone = 0 }
                        }
                    }
                }
            }
        }

        Item {
            id: bodyPanels
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: topTabBar.bottom
            anchors.bottom: parent.bottom
            anchors.topMargin: 12

            Rectangle {
                id: packagePanel
                anchors.left: parent.left
                anchors.top: parent.top
                anchors.bottom: parent.bottom
                width: Math.max(335, parent.width * 0.22)
                radius: 8
                color: "#E607101B"
                border.width: root.focusZone === 1 ? 2 : 1
                border.color: root.focusZone === 1 ? root.focusBlue : "#25313C"

                Item {
                    id: listHeader
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    height: 68
                    Text {
                        anchors.centerIn: parent
                        text: root.tabName().toUpperCase()
                        color: root.textPrimary
                        font.pixelSize: Math.round(20 * root.textScale)
                        font.bold: true
                        font.letterSpacing: 1.4
                    }
                    Text {
                        anchors.right: parent.right
                        anchors.rightMargin: 18
                        anchors.verticalCenter: parent.verticalCenter
                        text: String(root.visiblePackages.length)
                        color: root.cyan
                        font.pixelSize: Math.round(16 * root.textScale)
                        font.bold: true
                    }
                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 1
                        color: "#25313C"
                    }
                }

                ListView {
                    id: packageList
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: listHeader.bottom
                    anchors.bottom: parent.bottom
                    anchors.margins: 10
                    spacing: 8
                    clip: true
                    model: root.visiblePackages
                    currentIndex: root.packageIndex

                    delegate: Rectangle {
                        required property int index
                        required property var modelData
                        width: packageList.width
                        height: 108
                        radius: 8
                        color: root.packageIndex === index && root.packageEngaged ? "#263C5570" : "#111B2938"
                        border.width: root.focusZone === 1 && root.packageIndex === index ? 2 : 1
                        border.color: root.focusZone === 1 && root.packageIndex === index ? root.focusBlue : "#2B465C70"

                        Row {
                            anchors.fill: parent
                            anchors.margins: 10
                            spacing: 11

                            Rectangle {
                                width: 72
                                height: 72
                                radius: 10
                                anchors.verticalCenter: parent.verticalCenter
                                color: "#182439"
                                border.width: 1
                                border.color: "#35546C"
                                clip: true
                                Image {
                                    anchors.fill: parent
                                    anchors.margins: 4
                                    source: root.assetSource(modelData.icon || modelData.id, modelData.id, "icon")
                                    fillMode: Image.PreserveAspectFit
                                    smooth: true
                                }
                            }

                            Item {
                                width: parent.width - 83
                                height: parent.height

                                Text {
                                    id: rowTitle
                                    anchors.left: parent.left
                                    anchors.right: rowPill.left
                                    anchors.rightMargin: 8
                                    anchors.top: parent.top
                                    anchors.topMargin: 7
                                    text: modelData.name || modelData.id
                                    color: root.textPrimary
                                    font.pixelSize: Math.round(18 * root.textScale)
                                    font.bold: true
                                    elide: Text.ElideRight
                                }

                                Rectangle {
                                    id: rowPill
                                    anchors.right: parent.right
                                    anchors.top: parent.top
                                    anchors.topMargin: 5
                                    width: Math.max(80, rowPillText.implicitWidth + 22)
                                    height: 32
                                    radius: 16
                                    color: root.packagePillTone(modelData) === "warning" ? "#D9A31E" :
                                           root.packagePillTone(modelData) === "danger" ? "#D83A4E" : "#18AD68"
                                    border.width: 0
                                    Text {
                                        id: rowPillText
                                        anchors.centerIn: parent
                                        text: root.packagePillLabel(modelData)
                                        color: "#FFFFFF"
                                        font.pixelSize: Math.round(11 * root.textScale)
                                        font.bold: true
                                    }
                                }

                                Text {
                                    anchors.left: parent.left
                                    anchors.right: parent.right
                                    anchors.bottom: parent.bottom
                                    anchors.bottomMargin: 8
                                    text: (modelData.developer || "NeutronOS") + "  •  v" + (modelData.version || "0.0.0")
                                    color: root.textSecondary
                                    font.pixelSize: Math.round(12 * root.textScale)
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            hoverEnabled: true
                            onEntered: {
                                root.packageIndex = index
                                root.packageEngaged = true
                                root.focusZone = 1
                                root.actionIndex = 0
                                root.screenshotIndex = 0
                                root.refreshFootprint()
                            }
                            onClicked: {
                                root.packageIndex = index
                                root.packageEngaged = true
                                root.focusZone = 1
                                root.refreshFootprint()
                            }
                        }
                    }

                    Text {
                        anchors.centerIn: parent
                        visible: root.visiblePackages.length === 0
                        width: parent.width - 20
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                        text: root.tabIndex === 1 ? "No Updates Available" :
                              root.tabIndex === 2 ? "No Installed Store Packages" :
                              "No Packages Available"
                        color: root.textSecondary
                        font.pixelSize: Math.round(17 * root.textScale)
                        font.bold: true
                    }
                }
            }

            Rectangle {
                id: detailPanel
                anchors.left: packagePanel.right
                anchors.leftMargin: 12
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.bottom: parent.bottom
                radius: 8
                color: "#F007101B"
                border.width: root.focusZone === 2 ? 2 : 1
                border.color: root.focusZone === 2 ? root.focusBlue : "#25313C"
                property var item: root.detailPackage()
                property var primaryAction: root.primaryPackageAction(item)

                Rectangle {
                    id: primaryActionButton
                    visible: detailPanel.item.id && detailPanel.primaryAction && detailPanel.primaryAction.id
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    anchors.leftMargin: 24
                    anchors.rightMargin: 24
                    anchors.bottomMargin: 16
                    height: 58
                    radius: 8
                    color: detailPanel.primaryAction.tone === "warning" ? "#D9A31E" :
                           detailPanel.primaryAction.tone === "danger" ? "#D83A4E" : "#18AD68"
                    border.width: root.focusZone === 2 ? 3 : 0
                    border.color: root.focusBlue
                    Text {
                        anchors.centerIn: parent
                        text: backend && backend.busy && String(backend.activePackageId) === String(detailPanel.item.id)
                              ? String(backend.activeOperation || "WORKING").toUpperCase() + "…"
                              : String(detailPanel.primaryAction.label || "").toUpperCase()
                        color: "#FFFFFF"
                        font.pixelSize: Math.round(18 * root.textScale)
                        font.bold: true
                        font.letterSpacing: 1.2
                    }
                    MouseArea {
                        anchors.fill: parent
                        enabled: !backend || !backend.busy
                        onClicked: { root.focusZone = 2; root.activateAction() }
                    }
                }

                Flickable {
                    id: detailFlick
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.bottom: primaryActionButton.visible ? primaryActionButton.top : parent.bottom
                    anchors.margins: 20
                    anchors.bottomMargin: primaryActionButton.visible ? 14 : 20
                    clip: true
                    contentWidth: width
                    contentHeight: detailColumn.implicitHeight
                    boundsBehavior: Flickable.StopAtBounds

                    Column {
                        id: detailColumn
                        width: detailFlick.width
                        spacing: 12

                        Rectangle {
                            width: parent.width
                            height: Math.max(190, Math.min(245, parent.width * 0.18))
                            radius: 9
                            color: "#12081220"
                            border.width: 1
                            border.color: "#2A486278"
                            clip: true
                            Image {
                                anchors.fill: parent
                                source: root.artworkSource(detailPanel.item)
                                fillMode: Image.PreserveAspectCrop
                                smooth: true
                                opacity: 0.94
                            }
                            Rectangle {
                                anchors.fill: parent
                                gradient: Gradient {
                                    GradientStop { position: 0.0; color: "#08000000" }
                                    GradientStop { position: 1.0; color: "#70050711" }
                                }
                            }
                        }

                        Text {
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            text: detailPanel.item.id ? (detailPanel.item.name || detailPanel.item.id) : "NeutronOS App Store"
                            color: root.textPrimary
                            font.pixelSize: Math.round(28 * root.textScale)
                            font.bold: true
                            elide: Text.ElideRight
                        }

                        Text {
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            text: detailPanel.item.id
                                  ? (detailPanel.item.description || "No repository description provided.")
                                  : "Browse trusted signed NeutronOS packages. Focus an app to see its artwork, repository description, compatibility, permissions, dependencies, download footprint, screenshots, and install state."
                            color: root.textSecondary
                            font.pixelSize: Math.round(14 * root.textScale)
                            lineHeight: 1.16
                        }

                        Rectangle {
                            width: parent.width
                            height: 54
                            radius: 8
                            color: detailPanel.item.id && detailPanel.item.compatible ? "#241A3B2C" : "#271D1B26"
                            border.width: 1
                            border.color: detailPanel.item.id && detailPanel.item.compatible ? root.success :
                                          detailPanel.item.id ? root.danger : root.border
                            Text {
                                anchors.fill: parent
                                anchors.margins: 7
                                text: root.compatibilityText(detailPanel.item)
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                wrapMode: Text.WordWrap
                                color: detailPanel.item.id && detailPanel.item.compatible ? root.success :
                                       detailPanel.item.id ? root.danger : root.textSecondary
                                font.pixelSize: Math.round(17 * root.textScale)
                                font.bold: true
                            }
                        }

                        Text {
                            width: parent.width
                            text: "PERMISSIONS"
                            color: root.purple
                            font.pixelSize: Math.round(12 * root.textScale)
                            font.bold: true
                            font.letterSpacing: 1.0
                        }
                        Text {
                            width: parent.width
                            text: root.joinedOrFallback(root.permissionItems(detailPanel.item), "No elevated permissions declared")
                            color: root.textSecondary
                            font.pixelSize: Math.round(13 * root.textScale)
                            wrapMode: Text.WordWrap
                        }

                        Text {
                            width: parent.width
                            text: "DEPENDENCIES"
                            color: root.cyan
                            font.pixelSize: Math.round(12 * root.textScale)
                            font.bold: true
                            font.letterSpacing: 1.0
                        }
                        Text {
                            width: parent.width
                            text: root.missingDependenciesText(detailPanel.item)
                            color: root.textSecondary
                            font.pixelSize: Math.round(13 * root.textScale)
                            wrapMode: Text.WordWrap
                            lineHeight: 1.12
                        }

                        Rectangle {
                            width: parent.width
                            height: 94
                            radius: 8
                            color: "#141C2938"
                            border.width: 1
                            border.color: "#29445A70"
                            Grid {
                                anchors.fill: parent
                                anchors.margins: 11
                                columns: 4
                                columnSpacing: 18
                                rowSpacing: 3

                                Column {
                                    width: Math.max(145, (parent.width - 54) / 4)
                                    spacing: 3
                                    Text { text: "PACKAGE SIZE"; color: root.textMuted; font.pixelSize: Math.round(10 * root.textScale); font.bold: true }
                                    Text { text: root.packageSize(detailPanel.item); color: root.textPrimary; font.pixelSize: Math.round(16 * root.textScale); font.bold: true }
                                }
                                Column {
                                    width: Math.max(145, (parent.width - 54) / 4)
                                    spacing: 3
                                    Text { text: "MISSING DEPENDENCIES"; color: root.textMuted; font.pixelSize: Math.round(10 * root.textScale); font.bold: true }
                                    Text { text: detailPanel.item.id ? root.footprintText("missingDependencyBytes", "—") : "—"; color: root.warning; font.pixelSize: Math.round(16 * root.textScale); font.bold: true }
                                }
                                Column {
                                    width: Math.max(145, (parent.width - 54) / 4)
                                    spacing: 3
                                    Text { text: "TOTAL DOWNLOAD"; color: root.textMuted; font.pixelSize: Math.round(10 * root.textScale); font.bold: true }
                                    Text { text: detailPanel.item.id ? root.footprintText("totalDownloadBytes", "—") : "—"; color: root.textPrimary; font.pixelSize: Math.round(16 * root.textScale); font.bold: true }
                                }
                                Column {
                                    width: Math.max(145, (parent.width - 54) / 4)
                                    spacing: 3
                                    Text { text: "EST. DISK IMPACT"; color: root.textMuted; font.pixelSize: Math.round(10 * root.textScale); font.bold: true }
                                    Text { text: detailPanel.item.id ? root.diskImpactText() : "—"; color: root.textPrimary; font.pixelSize: Math.round(16 * root.textScale); font.bold: true }
                                }
                            }
                        }

                        Row {
                            width: parent.width
                            spacing: 14
                            Text {
                                text: "REPOSITORY"
                                color: root.textMuted
                                font.pixelSize: Math.round(11 * root.textScale)
                                font.bold: true
                            }
                            Text {
                                width: parent.width - 150
                                text: detailPanel.item.id ? (detailPanel.item.repositoryName || "NeutronOS Official") : "NeutronOS Official"
                                color: root.textPrimary
                                font.pixelSize: Math.round(15 * root.textScale)
                                font.bold: true
                                elide: Text.ElideRight
                            }
                        }

                        Text {
                            width: parent.width
                            text: "SCREENSHOTS"
                            color: root.cyan
                            font.pixelSize: Math.round(12 * root.textScale)
                            font.bold: true
                            font.letterSpacing: 1.0
                        }

                        Grid {
                            id: screenshotGrid
                            width: parent.width
                            columns: 2
                            spacing: 12
                            property real shotWidth: (width - spacing) / 2
                            Repeater {
                                model: 4
                                Rectangle {
                                    required property int index
                                    width: screenshotGrid.shotWidth
                                    height: width * 9 / 16
                                    radius: 8
                                    color: "#0B121D"
                                    border.width: 1
                                    border.color: "#30495B"
                                    clip: true
                                    property string shotSource: root.screenshotAt(detailPanel.item, index)
                                    Image {
                                        anchors.fill: parent
                                        source: parent.shotSource
                                        visible: parent.shotSource.length > 0
                                        fillMode: Image.PreserveAspectCrop
                                        smooth: true
                                        asynchronous: true
                                    }
                                    Text {
                                        anchors.centerIn: parent
                                        visible: parent.shotSource.length === 0
                                        text: detailPanel.item.id ? "SCREENSHOT " + (index + 1) : "APP SCREENSHOT"
                                        color: root.textMuted
                                        font.pixelSize: Math.round(12 * root.textScale)
                                        font.bold: true
                                    }
                                }
                            }
                        }

                        Item { width: 1; height: 8 }
                    }
                }
            }
        }
    }

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: referenceFooter.top
        height: backend && backend.busy ? 6 : 0
        visible: height > 0
        color: "#17243a"
        z: 51
        Rectangle {
            width: parent.width * (backend ? backend.progress : 0)
            height: parent.height
            color: root.focusBlue
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: backend && backend.busy &&
                 (String(backend.activeOperation) === "install" || String(backend.activeOperation) === "update")
        color: "#C800050B"
        z: 59

        Shared.ReferenceModalPanel {
            anchors.centerIn: parent
            width: Math.min(parent.width - 120, 820)
            height: 430
            radius: 30
            accentColor: String(backend && backend.activeOperation) === "update" ? root.warning : root.success

            Column {
                anchors.fill: parent
                anchors.margins: 38
                spacing: 22

                Text {
                    width: parent.width
                    text: String(backend && backend.activeOperation) === "update" ? "UPDATING APP" : "INSTALLING APP"
                    color: String(backend && backend.activeOperation) === "update" ? root.warning : root.success
                    font.pixelSize: Math.round(22 * root.textScale)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: {
                        var item = root.detailPackage()
                        return item && item.name ? String(item.name) : String(backend ? backend.activePackageId : "Package")
                    }
                    color: root.textPrimary
                    font.pixelSize: Math.round(27 * root.textScale)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideRight
                }

                Item {
                    width: parent.width
                    height: 58
                    Text {
                        anchors.centerIn: parent
                        text: "◌"
                        color: root.focusBlue
                        font.pixelSize: 48
                        font.bold: true
                        RotationAnimation on rotation {
                            from: 0
                            to: 360
                            duration: 850
                            loops: Animation.Infinite
                            running: root.backend && root.backend.busy
                        }
                    }
                }

                Text {
                    width: parent.width
                    text: backend ? String(backend.statusMessage || "Preparing package…") : "Preparing package…"
                    color: root.textSecondary
                    font.pixelSize: Math.round(16 * root.textScale)
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                }

                Rectangle {
                    width: parent.width
                    height: 22
                    radius: 11
                    color: "#16263A"
                    border.width: 1
                    border.color: root.border
                    clip: true

                    Rectangle {
                        height: parent.height
                        width: parent.width * Math.max(0, Math.min(1, backend ? Number(backend.progress || 0) : 0))
                        radius: parent.radius
                        color: String(backend && backend.activeOperation) === "update" ? root.warning : root.success
                        Behavior on width { NumberAnimation { duration: 120 } }
                    }
                }

                Text {
                    width: parent.width
                    text: Math.round(Math.max(0, Math.min(1, backend ? Number(backend.progress || 0) : 0)) * 100) + "%"
                    color: root.textPrimary
                    font.pixelSize: Math.round(18 * root.textScale)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: "Do not power off NeutronOS while package files are being changed."
                    color: root.textMuted
                    font.pixelSize: Math.round(13 * root.textScale)
                    horizontalAlignment: Text.AlignHCenter
                }
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.confirmOpen
        color: "#b8000000"
        z: 60
        Shared.ReferenceModalPanel {
            id: confirmPanel
            anchors.centerIn: parent
            width: 820
            height: 610
            radius: 30
            accentColor: root.confirmOperation === "uninstall" ? root.danger : root.focusBlue
            property var item: root.detailPackage()
            Column {
                anchors.fill: parent
                anchors.margins: 34
                spacing: 18
                Text {
                    text: root.confirmOperation.toUpperCase() + " " + (confirmPanel.item.name || "PACKAGE")
                    color: root.textPrimary
                    font.pixelSize: Math.round(29 * root.textScale)
                    font.bold: true
                }
                Text {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: root.confirmOperation === "update"
                          ? "The signed update is verified before the existing package is replaced. Transactional rollback protects the current version."
                          : root.confirmOperation === "uninstall"
                            ? "Only files owned by this App Store package are removed. Shared dependencies and shared services are preserved."
                            : "Review permissions and dependencies before downloading. Package integrity and signature are verified before files are changed."
                    color: root.textSecondary
                    font.pixelSize: Math.round(17 * root.textScale)
                }
                Rectangle {
                    width: parent.width
                    height: 130
                    radius: 20
                    color: "#24131f34"
                    Column {
                        anchors.fill: parent
                        anchors.margins: 18
                        spacing: 8
                        Text { text: "PERMISSIONS"; color: root.purple; font.pixelSize: Math.round(14 * root.textScale); font.bold: true }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            text: root.joinedOrFallback(root.permissionItems(confirmPanel.item), "No elevated permissions declared")
                            color: root.textPrimary
                            font.pixelSize: Math.round(15 * root.textScale)
                        }
                    }
                }
                Rectangle {
                    width: parent.width
                    height: 112
                    radius: 20
                    color: "#24131f34"
                    Column {
                        anchors.fill: parent
                        anchors.margins: 18
                        spacing: 7
                        Text { text: "DEPENDENCIES & SIZE"; color: root.cyan; font.pixelSize: Math.round(14 * root.textScale); font.bold: true }
                        Text {
                            width: parent.width
                            elide: Text.ElideRight
                            text: root.joinedOrFallback(root.dependencyItems(confirmPanel.item), "No additional dependencies declared")
                            color: root.textPrimary
                            font.pixelSize: Math.round(14 * root.textScale)
                        }
                        Text { text: root.packageSize(confirmPanel.item); color: root.textPrimary; font.pixelSize: Math.round(15 * root.textScale); font.bold: true }
                    }
                }
                Item { width: 1; height: 8 }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 22
                    Rectangle {
                        width: 280
                        height: 64
                        radius: 22
                        color: root.confirmOperation === "uninstall" ? "#35261620" : "#35204435"
                        border.width: 2
                        border.color: root.confirmOperation === "uninstall" ? root.danger : root.success
                        Text {
                            anchors.centerIn: parent
                            text: "X  CONFIRM"
                            color: root.confirmOperation === "uninstall" ? root.danger : root.success
                            font.pixelSize: Math.round(18 * root.textScale)
                            font.bold: true
                        }
                    }
                    Rectangle {
                        width: 280
                        height: 64
                        radius: 22
                        color: "#30231b2c"
                        border.width: 1
                        border.color: root.border
                        Text { anchors.centerIn: parent; text: "O  CANCEL"; color: root.textSecondary; font.pixelSize: Math.round(18 * root.textScale); font.bold: true }
                    }
                }
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.repositoriesOpen
        color: "#c0000000"
        z: 65
        Shared.ReferenceModalPanel {
            anchors.centerIn: parent
            width: 1050
            height: 720
            radius: 32
            accentColor: root.focusBlue
            Column {
                anchors.fill: parent
                anchors.margins: 32
                spacing: 16
                Text { text: "Trusted Repositories"; color: root.textPrimary; font.pixelSize: Math.round(30 * root.textScale); font.bold: true }
                Text {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: "X enables or disables a source. Developer Mode can add, trust, or remove custom repositories. Signed packages still require a trusted Ed25519 key."
                    color: root.textSecondary
                    font.pixelSize: Math.round(16 * root.textScale)
                }
                ListView {
                    id: repositoryList
                    width: parent.width
                    height: 520
                    model: backend ? backend.repositories : []
                    clip: true
                    spacing: 12
                    delegate: Rectangle {
                        required property int index
                        required property var modelData
                        width: repositoryList.width
                        height: 96
                        radius: 22
                        color: root.repositoryIndex === index ? "#3a214b69" : "#21131e31"
                        border.width: root.repositoryIndex === index ? 2 : 1
                        border.color: root.repositoryIndex === index ? root.focusBlue : root.border
                        Row {
                            anchors.fill: parent
                            anchors.margins: 16
                            spacing: 16
                            Rectangle { width: 12; height: 12; radius: 6; anchors.verticalCenter: parent.verticalCenter; color: modelData.enabled ? root.success : root.danger }
                            Column {
                                width: parent.width - 210
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 5
                                Text { width: parent.width; elide: Text.ElideRight; text: modelData.name; color: root.textPrimary; font.pixelSize: Math.round(19 * root.textScale); font.bold: true }
                                Text { width: parent.width; elide: Text.ElideMiddle; text: modelData.url; color: root.textSecondary; font.pixelSize: Math.round(13 * root.textScale) }
                            }
                            Rectangle {
                                width: 150
                                height: 42
                                radius: 17
                                anchors.verticalCenter: parent.verticalCenter
                                color: modelData.trusted ? "#30204435" : "#362e2518"
                                border.width: 1
                                border.color: modelData.trusted ? root.success : root.warning
                                Text { anchors.centerIn: parent; text: modelData.trusted ? "TRUSTED" : "UNTRUSTED"; color: modelData.trusted ? root.success : root.warning; font.pixelSize: Math.round(12 * root.textScale); font.bold: true }
                            }
                        }
                    }
                }
                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "X Enable/Disable  •  Triangle Add  •  Square Trust  •  R1 Remove  •  Start/O Close"; color: root.cyan; font.pixelSize: Math.round(15 * root.textScale); font.bold: true }
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.statusOpen
        color: "#b8000000"
        z: 70
        Shared.ReferenceModalPanel {
            anchors.centerIn: parent
            width: 760
            height: 310
            radius: 30
            accentColor: backend && backend.lastError.length ? root.danger : root.focusBlue
            Column {
                anchors.fill: parent
                anchors.margins: 32
                spacing: 24
                Text { text: backend && backend.lastError.length ? "App Store Notice" : "App Store"; color: root.textPrimary; font.pixelSize: Math.round(28 * root.textScale); font.bold: true }
                Text { width: parent.width; height: 130; wrapMode: Text.WordWrap; verticalAlignment: Text.AlignVCenter; text: root.toastText; color: root.textSecondary; font.pixelSize: Math.round(17 * root.textScale) }
                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "X / O  CLOSE"; color: root.cyan; font.pixelSize: Math.round(16 * root.textScale); font.bold: true }
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.analysisOpen
        color: "#c0000000"
        z: 75
        Shared.ReferenceModalPanel {
            anchors.centerIn: parent
            width: 980
            height: 570
            radius: 30
            accentColor: root.warning
            Column {
                anchors.fill: parent
                anchors.margins: 30
                spacing: 16
                Text { text: "Third-Party Package Analysis"; color: root.textPrimary; font.pixelSize: Math.round(29 * root.textScale); font.bold: true }
                Text {
                    text: backend ? String(backend.lastSecurityAnalysis.classification || "UNKNOWN") : "UNKNOWN"
                    color: text === "SAFE" ? root.success : text === "DANGEROUS" ? root.danger : root.warning
                    font.pixelSize: Math.round(25 * root.textScale)
                    font.bold: true
                }
                Text { width: parent.width; wrapMode: Text.WordWrap; text: backend ? String(backend.lastSecurityAnalysis.disclaimer || "") : ""; color: root.textSecondary; font.pixelSize: Math.round(15 * root.textScale) }
                ListView {
                    width: parent.width
                    height: 290
                    clip: true
                    spacing: 8
                    model: backend && backend.lastSecurityAnalysis.findings ? backend.lastSecurityAnalysis.findings : []
                    delegate: Text {
                        required property var modelData
                        width: ListView.view.width
                        wrapMode: Text.WordWrap
                        text: "• " + modelData.severity.toUpperCase() + " — " + modelData.description + (modelData.path ? " (" + modelData.path + ")" : "")
                        color: root.textSecondary
                        font.pixelSize: Math.round(14 * root.textScale)
                    }
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 18
                    Repeater {
                        model: ["Install", "Quarantine", "Remove"]
                        Rectangle {
                            required property int index
                            required property string modelData
                            width: 190
                            height: 58
                            radius: 20
                            color: root.analysisActionIndex === index ? "#49305f86" : "#21131e31"
                            border.width: root.analysisActionIndex === index ? 2 : 1
                            border.color: root.analysisActionIndex === index ? root.focusBlue : root.border
                            opacity: index === 0 && backend && backend.lastSecurityAnalysis.classification === "DANGEROUS" ? 0.4 : 1
                            Text {
                                anchors.centerIn: parent
                                text: modelData
                                color: index === 2 ? root.danger : index === 1 ? root.warning : root.success
                                font.pixelSize: Math.round(17 * root.textScale)
                                font.bold: true
                            }
                        }
                    }
                }
            }
        }
    }

    Shared.ReferenceExitModal {
        id: referenceExitModal
        appName: "App Store"
        onExitRequested: root.exitRequested()
        onLeaveRunningRequested: root.backgroundRequested()
        onDismissed: { root.exitOpen = false; root.focusZone = 0; root.forceActiveFocus() }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.keyboardOpen
        color: "#b9000000"
        z: 80
        Column {
            anchors.centerIn: parent
            spacing: 12
            Rectangle {
                width: virtualKeyboard.width
                height: 64
                radius: 18
                color: "#f20c1424"
                border.width: 2
                border.color: root.focusBlue
                Text {
                    anchors.fill: parent
                    anchors.margins: 16
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideMiddle
                    text: root.keyboardBuffer.length ? root.keyboardBuffer :
                          (root.keyboardPurpose === "search" ? "Search packages" : "Path to .napp package")
                    color: root.textPrimary
                    font.pixelSize: Math.round(18 * root.textScale)
                }
            }
            Shared.VirtualKeyboard {
                id: virtualKeyboard
                visibleMode: root.keyboardOpen
                active: root.keyboardOpen
                largeMode: false
                title: root.keyboardPurpose === "search" ? "Search App Store" : "Manual NeutronOS Package"
                onKeyPressed: function(value) { root.appendKeyboard(value) }
                onBackspacePressed: { if (root.keyboardBuffer.length) root.keyboardBuffer = root.keyboardBuffer.slice(0, -1) }
                onEnterPressed: root.finishKeyboard()
                onClosePressed: { root.keyboardOpen = false; root.keyboardPurpose = "" }
            }
        }
    }
}
