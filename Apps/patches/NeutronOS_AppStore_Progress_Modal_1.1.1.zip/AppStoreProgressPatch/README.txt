NeutronOS App Store progress modal patch for Neutron Media Libraries 1.1.1 testing

Purpose:
- Adds a blocking progress modal for App Store INSTALL and UPDATE operations.
- Uses existing AppStoreManager busy/progress/statusMessage state.
- Shows operation, package name, current phase, progress bar, percentage, and a do-not-power-off warning.
- Captures controller input while install/update is active.
- Leaves the transactional package model unchanged.
- Adds no package-provided install.sh/uninstall.sh lifecycle execution.

QML-only. No C++ rebuild is required.
The apply script only accepts the validated Reference Redesign v3 Main.qml or the already-patched file.
