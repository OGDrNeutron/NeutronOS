# NeutronOS Gemini Games — local development review

This is an independent Gemini AMD64 application with package identity `gemini-games`.
It has native Qt 6.8.2/QML screens, a C++ library/index and runtime backend, owned
process supervision, and a Gemini-only evdev/uinput controller service.

**This candidate is not release ready.** Physical acceptance is reserved for the
user's development PC; no controller, USB or host-display changes were made. Mandatory actual-game controller,
Weston focus/overlay, hardware performance, and privileged installation tests
remain outstanding. A disposable COW Gemini VM and an isolated GPU-backed Weston test display are available. The staged OS integration patch has not been
installed into Gemini 0.5.4. Steam/Proton session supervision, automatic emulator
profile provisioning remain incomplete. Runtime installation review now uses the existing App Store;
actual provisioning awaits a compatible signed provider and an installation test.
Artwork and the exact Recovery footer animation are documented in `docs/ARTWORK-AND-FOOTER.md`. Signing establishes artifact integrity; it does not establish those behaviors.

No original Apollo or Gemini 0.5.4 release-candidate files were changed. Nothing
was committed, pushed, published, or installed into the running system. The
live Gemini catalog remains unchanged.

* App source: `source/qml/apps/gemini-games/`
* Backend/index/adapters: `source/src/package_apps/gemini-games/`
* Controller service: `source/scripts/apps/gemini-games/controller_proxy.py`
* Signed local package: `Apps/Gemini/Gemini-Games-0.1.0-review.1.napp`
* Staged existing catalog: `staging/repository/Apps/Gemini/index.json` and `.sig`
* Separate OS support patch: `staging/os-integration/gemini-games-session.patch`
* Review and acceptance evidence: `docs/VALIDATION.md`, `validation/`

The source tree is an isolated copy of the current Gemini 0.5.4 source. Changes
outside the package consist only of conditional Games hooks in `qml/Main.qml`
and exclusion of the Games virtual pads from duplicate system registration in
`src/ControllerManager.cpp`. Existing physical-controller detection, connection,
registration, transport, battery, Bluetooth and USB implementations are retained.

Current NAPP `buildFiles` can target only `src/package_apps/gemini-games/`; they
cannot distribute those two OS hooks. Review the separate patch as Gemini OS
support. Launch fails closed when the authenticated session integration is
absent; browsing the library does not require launch support.

Run `tools/in-build-root` only against this workspace. It uses the retained
Debian 13 build root through PRoot and may require sandbox approval for ptrace.
Native validation executables use the retained Qt libraries; commands and
limitations are in `docs/VALIDATION.md`. Do not deploy this review candidate
before completing the blocked acceptance checks.

Read-only validation of /NeutronMedia/Games/ is documented in `docs/USER-LIBRARY.md`.
Archives require extracted data and a verified runtime; none was extracted or run.
