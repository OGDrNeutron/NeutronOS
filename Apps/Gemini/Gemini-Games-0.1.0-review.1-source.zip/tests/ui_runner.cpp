#include "GeminiGamesBackend.h"
#include "../source/src/GeminiGeometry.h"
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQmlProperty>
#include <QJSValue>
#include <QQuickWindow>
#include <QTimer>
#include <QTest>
#include <QTemporaryDir>
#include <QJsonArray>
#include <QJsonDocument>
#include <QSaveFile>
#include <QPainter>
#include <QPainterPath>
#include <time.h>
using namespace GeminiGames;
class StoreFixture final:public QObject {
Q_OBJECT
Q_PROPERTY(QVariantList catalog MEMBER catalog NOTIFY catalogChanged)
Q_PROPERTY(bool busy MEMBER busy NOTIFY busyChanged)
Q_PROPERTY(QString lastError MEMBER error CONSTANT)
public:
QVariantList catalog;bool busy=false;QString error;int installs=0;bool known=true;
StoreFixture(){catalog={QVariantMap{{"id","unverified-wine"},{"name","Wine unsigned fixture"},{"signatureReady",false},{"compatible",true},{"storeEligible",true}},QVariantMap{{"id","review-wine"},{"name","Wine fixture"},{"description","Runtime approval fixture"},{"signatureReady",true},{"catalogVerified",true},{"repositoryTrusted",true},{"compatible",true},{"storeEligible",true},{"packageUrl","https://example.invalid/review-wine.napp"},{"repositoryName","Fixture repository"},{"debianDependencies",QStringList{"wine-fixture"}},{"permissions",QStringList{"filesystem"}}}};}
Q_INVOKABLE QVariantMap packageById(QString id){for(auto p:catalog)if(p.toMap().value("id")==id)return p.toMap();return {};}
Q_INVOKABLE QVariantMap installFootprint(QString){return {{"known",known},{"totalInstalledBytes",1000000},{"totalDownloadBytes",500000},{"diskEstimateLowerBound",false}};}
Q_INVOKABLE QString formatBytes(qulonglong bytes){return QString::number(bytes)+" B";}
Q_INVOKABLE bool installPackage(QString){installs++;return true;}
Q_INVOKABLE bool updatePackage(QString){installs++;return true;}
signals:void catalogChanged();void busyChanged();void operationFinished(QString,QString,bool,QString);
};
class Fixture final:public QObject {
Q_OBJECT
Q_PROPERTY(QVariantList artworkFiles READ artworkFiles NOTIFY changed)
Q_PROPERTY(QString artworkDirectory READ artworkDirectory CONSTANT)
Q_PROPERTY(QString recoveryVisualRoot READ recoveryVisualRoot CONSTANT)
Q_PROPERTY(QStringList artworkFormats READ artworkFormats CONSTANT)
Q_PROPERTY(QVariantList games READ games NOTIFY changed)
Q_PROPERTY(QVariantList roots READ roots NOTIFY changed)
Q_PROPERTY(QVariantList messages READ messages NOTIFY changed)
Q_PROPERTY(QVariantList installedRuntimes READ installedRuntimes CONSTANT)
Q_PROPERTY(QVariantMap hardware READ hardware CONSTANT)
Q_PROPERTY(QVariantMap preferences MEMBER prefs NOTIFY changed)
Q_PROPERTY(bool scanning READ scanning CONSTANT)
Q_PROPERTY(bool gameActive MEMBER playing NOTIFY sessionChanged)
Q_PROPERTY(bool menuOpen MEMBER menuShown NOTIFY sessionChanged)
Q_PROPERTY(bool stopTimedOut MEMBER timedOut NOTIFY sessionChanged)
Q_PROPERTY(QString gameTitle READ title CONSTANT)
Q_PROPERTY(bool gamingMode READ inactive CONSTANT)
Q_PROPERTY(bool backgrounded MEMBER bg NOTIFY sessionChanged)
Q_PROPERTY(int controllerCount READ controllerCount CONSTANT)
Q_PROPERTY(QString menuSource MEMBER menuSource NOTIFY sessionChanged)
public:
bool playing=false,bg=false,menuShown=false,timedOut=false;int resumes=0,closes=0,forces=0;
QString title()const{return "Session fixture";}
Q_INVOKABLE bool resumeGame(){resumes++;menuShown=false;emit sessionChanged();return true;}
Q_INVOKABLE void closeGame(){closes++;}
Q_INVOKABLE void forceCloseGame(){forces++;menuShown=false;emit sessionChanged();}
GeminiGamesBackend *timerBackend;QString visualRoot;QTemporaryDir temp;GameLibrary library;GameArtwork artwork;QVariantMap prefs;QString menuSource;QVariantList msg;
Fixture(const QString &work,GeminiGamesBackend *timers):timerBackend(timers),visualRoot(QUrl::fromLocalFile(QDir("/opt/neutronos/qml/gemini").exists()?QString("/opt/neutronos/qml/gemini/"):work+"/source/qml/gemini/").toString()),library(temp.path()),artwork(temp.path()){
 QDir().mkpath(temp.path()+"/Games");
 for(int i=0;i<18;i++){QFile f(temp.path()+"/Games/Native fixture "+QString::number(i)+".nes");f.open(QIODevice::WriteOnly);f.write(QByteArray("NES\x1a",4)+QByteArray(64,char(i)));}
 QImage custom(600,900,QImage::Format_RGB32);custom.fill(QColor("#1253a4"));QPainter artpaint(&custom);artpaint.setPen(QColor("#66ddff"));artpaint.setFont(QFont("Sans",30,QFont::Bold));artpaint.drawText(custom.rect(),Qt::AlignCenter,"Native fixture 0\nCustom Artwork");artpaint.end();custom.save(artwork.directory()+"/Native fixture 0.PNG");
 library.rescan();QTest::qWait(1000);
 connect(timerBackend,&GeminiGamesBackend::footerTimeout,this,&Fixture::footerTimeout);
 connect(&library,&GameLibrary::changed,this,&Fixture::changed);connect(&artwork,&GameArtwork::changed,this,&Fixture::changed);
}
QVariantList games() const{return artwork.decorate(library.games());}
QVariantList artworkFiles()const{return artwork.files();}
QString artworkDirectory()const{return artwork.directory();}
QString recoveryVisualRoot()const{return visualRoot;}
QStringList artworkFormats()const{return artwork.formats();}
Q_INVOKABLE void startFooterCountdown(){timerBackend->startFooterCountdown();}
Q_INVOKABLE void cancelFooterCountdown(){timerBackend->cancelFooterCountdown();}
Q_INVOKABLE void refreshArtwork(){artwork.refresh();}
Q_INVOKABLE bool setArtworkAssignment(QString id,QString path){if(!path.isEmpty()&&!artwork.contains(path))return false;return library.update(id,{{"artworkOverride",path}});}QVariantList roots()const{return library.roots();}QVariantList messages()const{return msg;}
QVariantList installedRuntimes()const{return RuntimeAdapters::runtimes();}QVariantMap hardware()const{return RuntimeAdapters::hardware();}
bool scanning()const{return false;}bool inactive()const{return false;}int controllerCount()const{return 0;}
Q_INVOKABLE bool initialize(){return true;}
Q_INVOKABLE QVariantMap uiState()const{return {};}
Q_INVOKABLE void setUiState(QVariantMap){}
Q_INVOKABLE void attachWindow(QObject*){}
Q_INVOKABLE void acknowledge(int index){auto m=msg[index].toMap();m["acknowledged"]=true;msg[index]=m;emit changed();}
Q_INVOKABLE void notify(const QString &s,bool critical=false){msg.append(QVariantMap{{"text",s},{"critical",critical},{"acknowledged",false}});emit changed();emit messagePublished(s,critical);}
Q_INVOKABLE QVariantList recommendations(const QString &id)const{return RuntimeAdapters::recommendations(library.find(id),hardware(),installedRuntimes());}
Q_INVOKABLE bool setPreference(const QString &key,const QVariant &value){prefs[key]=value;emit changed();return true;}
Q_INVOKABLE bool favorite(const QString &id,bool v){return library.update(id,{{"favorite",v}});}
Q_INVOKABLE bool choosePlatform(const QString &id,const QString &kind){return library.update(id,{{"chosenKind",kind}});}
Q_INVOKABLE void refreshRuntimes(){emit changed();}
Q_INVOKABLE void rescan(){library.rescan();}
Q_INVOKABLE bool addFolder(const QString &p){return library.addRoot(p);}
Q_INVOKABLE bool editFolder(int i,const QString &p){return library.editRoot(i,p);}
Q_INVOKABLE bool removeFolder(int i){return library.removeRoot(i);}
Q_INVOKABLE bool configure(QString,QVariantMap,bool){return false;}
Q_INVOKABLE bool setControllerProfile(QString id,QVariantMap profile){return library.update(id,{{"controllerProfile",profile}});}
Q_INVOKABLE bool updateMetadata(QString,QString,QString){return false;}
Q_INVOKABLE bool play(QString){return false;}
Q_INVOKABLE bool prepareSwitch(){return true;}
Q_INVOKABLE QString logPath(){return temp.path();}
Q_INVOKABLE QVariantMap resourceSample(){return {};}
signals:void footerTimeout();void modalAction(QString action);void changed();void sessionChanged();void restoreRequested();void messagePublished(QString,bool);
};
static double cpu(){timespec t{};clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec/1e9;}
static QVariantMap sample(const QString &phase,double initial,int ms){QVariantMap r{{"phase",phase},{"seconds",double(ms)/1000},{"processCpuPercent",100*(cpu()-initial)/(double(ms)/1000)}};QFile f("/proc/self/status");if(f.open(QIODevice::ReadOnly))for(const auto &line:f.readAll().split('\n'))if(line.startsWith("VmRSS:")||line.startsWith("VmHWM:"))r[QString::fromLatin1(line.left(line.indexOf(':')))]=QString::fromLatin1(line.mid(line.indexOf(':')+1)).trimmed();return r;}
int main(int argc,char **argv){
 QGuiApplication app(argc,argv);QString work=app.arguments().value(1,"/games");GeminiGamesBackend linkage;Fixture fixture(work,&linkage);qmlRegisterType<GeminiRingGeometry>("NeutronGemini",1,0,"GeminiRingGeometry");QQmlApplicationEngine engine;engine.rootContext()->setContextProperty("testBackend",&fixture);engine.rootContext()->setContextProperty("testWork",work);engine.load(QUrl::fromLocalFile(work+"/tests/ui.qml"));if(engine.rootObjects().isEmpty())return 2;
 auto window=qobject_cast<QQuickWindow*>(engine.rootObjects().first());auto root=window->findChild<QObject*>("GeminiGamesApp");if(!root)return 3;
 QVariantList checks;
 auto check=[&](QString name,bool ok){checks.append(QVariantMap{{"name",name},{"passed",ok}});if(!ok)qWarning()<<"UI check failed:"<<name;};
 auto press=[&](QString s){QVariant arg=s;QMetaObject::invokeMethod(root,"handleControllerPressed",Q_ARG(QVariant,arg));QCoreApplication::processEvents();};
 QTest::qWait(500);
 auto atomLoader=window->findChild<QObject*>("GamesRecoveryAtomLoader");
 check("actual Recovery atom component loaded",atomLoader&&atomLoader->property("item").value<QObject*>());
 auto firstAtom=window->grabWindow().copy(12,window->height()-72,70,70);window->grabWindow().save(work+"/validation/footer-atom-frame-1.png");QTest::qWait(600);auto secondAtom=window->grabWindow().copy(12,window->height()-72,70,70);window->grabWindow().save(work+"/validation/footer-atom-frame-2.png");check("Recovery atom pixels animate",!firstAtom.isNull()&&firstAtom!=secondAtom);
 for(int page=0;page<8;page++){root->setProperty("page",page);root->setProperty("zone",page==7?"tabs":"content");QTest::qWait(120);window->grabWindow().save(work+"/validation/ui-page-"+QString::number(page)+".png");check("page "+QString::number(page)+" rendered",!window->grabWindow().isNull());}
 root->setProperty("page",0);root->setProperty("zone","nav");check("footer initially visible",root->property("footerVisible").toBool());QTest::qWait(10200);check("footer hides after 10 seconds",!root->property("footerVisible").toBool());check("hidden footer releases actual atom",atomLoader&&!atomLoader->property("active").toBool()&&!atomLoader->property("item").value<QObject*>());press("system");check("Start opens footer",root->property("footerVisible").toBool());press("secondary");check("Triangle opens installed carousel",root->property("installedCarousel").toBool());press("up");check("leaving footer dismisses carousel",!root->property("installedCarousel").toBool());press("system");check("Start closes footer",!root->property("footerVisible").toBool());press("system");QTest::qWait(10200);check("manual footer remains visible",root->property("footerVisible").toBool());root->setProperty("visible",false);QCoreApplication::processEvents();check("background Games releases footer atom",!atomLoader->property("active").toBool()&&!atomLoader->property("item").value<QObject*>());root->setProperty("visible",true);QTest::qWait(150);check("returning Games restores footer atom",atomLoader->property("item").value<QObject*>());fixture.playing=true;emit fixture.sessionChanged();QCoreApplication::processEvents();check("active gameplay suspends footer atom",!atomLoader->property("active").toBool());fixture.bg=true;emit fixture.sessionChanged();QCoreApplication::processEvents();check("visible Games can animate with backgrounded game",atomLoader->property("active").toBool());fixture.playing=false;fixture.bg=false;emit fixture.sessionChanged();press("system");
 root->setProperty("zone","nav");for(int i=0;i<7;i++)press("down");check("controller reaches Settings",root->property("page").toInt()==7);press("right");press("down");press("primary");check("Add Folder dialog opens",root->property("dialogOpen").toBool());press("primary");check("controller keyboard opens",root->property("keyboardOpen").toBool());press("cancel");press("cancel");check("dialog returns focus",root->property("zone").toString()=="settings");
 fixture.notify("Critical fixture",true);press("context");check("message is controller reachable",root->property("zone").toString()=="messages");press("primary");check("X acknowledges critical message",fixture.messages().last().toMap().value("acknowledged").toBool());
 root->setProperty("page",7);root->setProperty("settingsTab",5);root->setProperty("settingsRow",0);root->setProperty("selectedGame",0);root->setProperty("zone","settings");auto artworkGame=root->property("currentGame").value<QJSValue>().toVariant().toMap();auto artworkGameId=artworkGame.value("id").toString();press("primary");check("artwork management opens through controller",root->property("dialogOpen").toBool()&&root->property("dialogKind").toString()=="artwork");press("down");press("primary");check("artwork refresh keeps focus",root->property("dialogOpen").toBool());window->grabWindow().save(work+"/validation/ui-artwork-management.png");press("down");press("primary");check("controller assigns a real custom image",!root->property("dialogOpen").toBool()&&!fixture.library.find(artworkGameId).value("artworkOverride").toString().isEmpty());press("primary");press("primary");check("controller restores automatic artwork",fixture.library.find(artworkGameId).value("artworkOverride").toString().isEmpty());
 root->setProperty("page",7);root->setProperty("settingsTab",4);root->setProperty("settingsRow",1);root->setProperty("zone","settings");press("primary");
 auto profileEditor=window->findChild<QObject*>("GamesControllerProfile");
 check("controller profile opens a named-button editor",profileEditor&&profileEditor->property("visible").toBool());
 if(profileEditor){
     window->grabWindow().save(work+"/validation/ui-controller-profile.png");
     auto id=root->property("currentGame").value<QJSValue>().toVariant().toMap().value("id").toString();
     press("primary");auto mapping=profileEditor->property("mapping").value<QJSValue>().toVariant().toMap();
     check("button remapping swaps both controls without duplicates",mapping.value("304").toInt()==305&&mapping.value("305").toInt()==304);
     for(int i=0;i<10;i++)press("down");press("primary");
     check("stick inversion is a controller toggle",profileEditor->property("inverted").value<QJSValue>().toVariant().toList().contains(1));
     press("down");press("down");press("primary");
     auto saved=fixture.library.find(id).value("controllerProfile").toMap();
     check("profile save persists remapping and inversion",saved.value("buttons").toMap().value("304").toInt()==305&&saved.value("invertAxes").toList().contains(1));
     check("profile save returns prior controller focus",!root->property("dialogOpen").toBool()&&root->property("zone").toString()=="settings");
     press("primary");press("down");press("down");press("cancel");
     check("profile cancellation preserves saved profile",fixture.library.find(id).value("controllerProfile").toMap()==saved);
     press("primary");for(int i=0;i<13;i++)press("down");press("primary");press("up");press("primary");
     check("controller can restore default mapping",fixture.library.find(id).value("controllerProfile").toMap().value("buttons").toMap().isEmpty());
 }
 if(root->property("dialogOpen").toBool())press("cancel");
 StoreFixture store;root->setProperty("storeBackend",QVariant::fromValue(static_cast<QObject*>(&store)));
 root->setProperty("page",7);root->setProperty("settingsTab",2);root->setProperty("settingsRow",1);root->setProperty("zone","settings");press("primary");
 auto dependency=window->findChild<QObject*>("GamesRuntimeApproval");
 check("missing runtime opens approval review without installation",dependency&&dependency->property("visible").toBool()&&store.installs==0);
 if(dependency){
     auto providers=dependency->property("providers").value<QJSValue>().toVariant().toList();
     check("runtime review excludes unsigned providers",providers.size()==1&&providers.first().toMap().value("id")=="review-wine");
     press("primary");check("selecting provider only opens confirmation",store.installs==0&&dependency->property("confirming").toBool());
     store.known=false;press("primary");check("unknown dependency footprint blocks install",store.installs==0);press("cancel");press("cancel");
     check("cancelling runtime review restores focus",!root->property("dialogOpen").toBool()&&root->property("zone")=="settings");
     store.known=true;press("primary");press("primary");window->grabWindow().save(work+"/validation/ui-runtime-approval.png");press("primary");
     check("explicit runtime approval dispatches existing App Store install",store.installs==1&&!root->property("dialogOpen").toBool());
     press("primary");press("primary");store.catalog={};emit store.catalogChanged();press("primary");
     check("changed catalog cannot install stale provider",store.installs==1);press("cancel");press("cancel");
 }
 if(root->property("dialogOpen").toBool())press("cancel");
 // Exercise every settings tab's controller path without invoking unsupported controls.
 root->setProperty("page",7);root->setProperty("settingsTab",0);root->setProperty("zone","tabs");
 for(int tab=0;tab<8;tab++){if(tab)press("right");check("Settings tab "+QString::number(tab)+" reachable",root->property("settingsTab").toInt()==tab);press("down");auto rows=root->property("settingRows").value<QJSValue>().toVariant().toList();for(int row=1;row<rows.size();row++)press("down");check("Settings tab "+QString::number(tab)+" last action reachable",root->property("settingsRow").toInt()==rows.size()-1);root->setProperty("zone","tabs");}
 auto modal=window->findChild<QObject*>("GameMenuValidation");check("game modal loaded",modal!=nullptr);
 if(modal){auto menuPress=[&](QString action){emit fixture.modalAction(action);};fixture.menuShown=true;emit fixture.sessionChanged();QTest::qWait(100);window->grabWindow().save(work+"/validation/ui-game-menu.png");check("game modal visible",modal->property("visible").toBool());menuPress("primary");check("Resume calls session and dismisses modal",fixture.resumes==1&&!fixture.menuShown);fixture.menuShown=true;emit fixture.sessionChanged();menuPress("down");menuPress("primary");check("Close calls graceful session action",fixture.closes==1);fixture.timedOut=true;emit fixture.sessionChanged();menuPress("primary");check("Force action calls only after timeout",fixture.forces==1&&!fixture.menuShown);}
 QVariantList performance;double initial=cpu();QTest::qWait(5000);performance.append(sample("visible idle Games QML",initial,5000));window->setPersistentSceneGraph(false);window->setPersistentGraphics(false);window->hide();window->releaseResources();initial=cpu();QTest::qWait(5000);performance.append(sample("hidden window with released scene resources",initial,5000));window->show();initial=cpu();QTest::qWait(5000);performance.append(sample("restored window",initial,5000));
 QSaveFile report(work+"/validation/ui-results.json");report.open(QIODevice::WriteOnly);report.write(QJsonDocument::fromVariant(QVariantMap{{"checks",checks},{"performance",performance},{"environment",qEnvironmentVariable("GAMES_TEST_ENVIRONMENT","Retained Gemini Qt libraries on isolated development display; scanner fixtures; no game launched by this runner")},{"actualGamePerformanceMeasured",false}}).toJson());report.commit();
 QImage icon(512,512,QImage::Format_ARGB32);icon.fill(QColor("#031021"));QPainter paint(&icon);paint.setRenderHint(QPainter::Antialiasing);QPen blue(QColor("#14caff"),10);paint.setPen(blue);QPainterPath pad;pad.moveTo(130,170);pad.cubicTo(100,155,72,280,75,350);pad.cubicTo(90,410,140,350,175,315);pad.lineTo(335,315);pad.cubicTo(380,365,425,405,440,350);pad.cubicTo(455,285,420,155,380,170);pad.closeSubpath();paint.drawPath(pad);paint.drawLine(150,220,150,285);paint.drawLine(118,252,182,252);paint.setPen(QPen(QColor("#ef235b"),9));for(auto pt:{QPoint(353,222),QPoint(391,250),QPoint(353,280),QPoint(318,250)})paint.drawEllipse(pt,9,9);paint.end();icon.save(work+"/validation/gemini-games.png");
 bool passed=true;for(const auto &v:checks)passed&=v.toMap().value("passed").toBool();return passed?0:1;
}
#include "ui_runner.moc"
