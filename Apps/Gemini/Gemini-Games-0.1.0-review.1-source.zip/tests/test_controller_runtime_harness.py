"""The VM readiness check must never accept another run's SDL snapshot."""
import importlib.util,json,pathlib,tempfile,unittest

spec=importlib.util.spec_from_file_location('sdl_harness',pathlib.Path(__file__).with_name('controller_sdl_vm.py'))
harness=importlib.util.module_from_spec(spec);spec.loader.exec_module(harness)
class SnapshotTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.saved=(harness.SNAPSHOT,harness.EXPECTED_TOKEN)
  harness.SNAPSHOT=pathlib.Path(self.temp.name)/'snapshot.json';harness.EXPECTED_TOKEN='current-run'
 def tearDown(self):
  harness.SNAPSHOT,harness.EXPECTED_TOKEN=self.saved;self.temp.cleanup()
 def test_previous_run_cannot_signal_readiness(self):
  harness.SNAPSHOT.write_text(json.dumps({'sessionToken':'previous-run','gameControllers':2}));self.assertEqual(harness.snapshot(),{})
 def test_unmarked_snapshot_cannot_signal_readiness(self):
  harness.SNAPSHOT.write_text(json.dumps({'gameControllers':2}));self.assertEqual(harness.snapshot(),{})
 def test_current_consumer_signals_readiness(self):
  state={'sessionToken':'current-run','gameControllers':2};harness.SNAPSHOT.write_text(json.dumps(state));self.assertEqual(harness.snapshot(),state)
 def test_missing_or_partial_output_is_not_ready(self):
  self.assertEqual(harness.snapshot(),{});harness.SNAPSHOT.write_text('{');self.assertEqual(harness.snapshot(),{})
if __name__=='__main__':unittest.main(verbosity=2)
