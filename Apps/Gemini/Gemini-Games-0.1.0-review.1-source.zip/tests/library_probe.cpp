#include "GameLibrary.h"
#include "RuntimeAdapters.h"
#include <QCoreApplication>
#include <QElapsedTimer>
#include <QFileInfo>
#include <QJsonDocument>
#include <QSaveFile>
#include <QTemporaryDir>
#include <QTest>
using namespace GeminiGames;
int main(int argc,char **argv){
    QCoreApplication app(argc,argv);
    if(app.arguments().size()!=3)return 2;
    QString root=QFileInfo(app.arguments()[1]).canonicalFilePath(),output=app.arguments()[2];
    if(root.isEmpty()||!QFileInfo(root).isDir())return 3;
    QTemporaryDir state(QFileInfo(output).absolutePath()+"/library-probe-XXXXXX");if(!state.isValid())return 4;
    QVariantList messages,entries;bool removed=false,filesRemain=true,repeatStable=false;
    {
        GameLibrary library(state.path());library.setAutomatic(false);
        QObject::connect(&library,&GameLibrary::error,[&](QString s){messages.append(s);});
        if(!library.addRoot(root))return 5;
        QElapsedTimer timer;timer.start();
        do {QTest::qWait(100);}while((library.scanning()||library.games().isEmpty()||timer.elapsed()<600)&&timer.elapsed()<30000);
        if(library.scanning()||library.games().isEmpty())return 6;
        auto hardware=RuntimeAdapters::hardware();auto runtimes=RuntimeAdapters::runtimes();
        for(const auto &value:library.games()){
            auto game=value.toMap();game["recommendations"]=RuntimeAdapters::recommendations(game,hardware,runtimes);entries.append(game);
        }
        library.rescan(root);QTest::qWait(500);
        timer.restart();while(library.scanning()&&timer.elapsed()<30000)QTest::qWait(100);
        repeatStable=library.games().size()==entries.size();
        removed=library.removeRoot(1);
        for(const auto &value:entries)filesRemain=filesRemain&&QFileInfo::exists(value.toMap().value("path").toString());
    }
    QVariantMap report{{"root",root},{"stateLocation","Temporary isolated workspace state, removed after test"},{"readOnlyGameAccess",true},{"gameLaunchAttempted",false},{"extractionPerformed",false},{"entries",entries},{"scanMessages",messages},{"repeatScanStable",repeatStable},{"removeRootSucceeded",removed},{"originalFilesRemain",filesRemain},{"runtimeProbe",RuntimeAdapters::runtimes()}};
    QSaveFile f(output);if(!f.open(QIODevice::WriteOnly))return 7;f.write(QJsonDocument::fromVariant(report).toJson());if(!f.commit())return 8;
    return repeatStable&&removed&&filesRemain?0:9;
}
