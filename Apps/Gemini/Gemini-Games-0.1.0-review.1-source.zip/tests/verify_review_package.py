#!/usr/bin/env python3
"""Fresh offline verification through Gemini's existing production verifier."""
from pathlib import Path
import hashlib, importlib.util, json, runpy, tempfile, zipfile

W=Path(__file__).resolve().parents[1]
S=W/'source'
KEY=S/'deployment/etc/neutronos/keys/neutronos-release.gpg'
RELEASE=S/'scripts/neutronos-release-verify'
VERIFIER=runpy.run_path(str(S/'scripts/neutronos-napp-verify.py'))['verify_napp']
spec=importlib.util.spec_from_file_location('package_helper',S/'scripts/neutronos-appstore-package.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)

def verify(path,**expectations):
    # Offline tests use the retained public key as a user-owned read-only file.
    # The installed production verifier still mandates root ownership.
    return VERIFIER(path,platform='gemini',architecture='amd64',key_path=KEY,release_verifier=RELEASE,require_owner=False,**expectations)

def main():
    stage=W/'staging/repository/Apps/Gemini'
    catalog=json.loads((stage/'index.json').read_text())
    release=runpy.run_path(str(RELEASE))['verify']
    identity=release((stage/'index.json').read_bytes(),(stage/'index.json.sig').read_bytes(),key_path=KEY,require_owner=False)
    entry=next(p for p in catalog['packages'] if p['id']=='gemini-games')
    package=stage/entry['packageUrl']
    result=verify(package,expected_sha=entry['sha256'],expected_id=entry['id'],expected_version=entry['version'])
    manifest,members=helper.inspect_archive(package)
    assert manifest['platforms']==entry['platforms']==['gemini']
    assert manifest['architectures']==entry['architectures']==['amd64']
    assert manifest['uninstallState']==[]
    assert helper.package_needs_privileged_install(manifest)
    assert helper.version_is_newer('0.1.0-review.1','0.0.0')
    assert not helper.version_is_newer(entry['version'],entry['version'])
    tests=[]
    fixtures=Path('/NeutronMedia/NeutronOS-Gemini/revisions/0.5.4/validation/appstore/fixtures')
    for name in ('unsigned','modified-payload','modified-manifest','bad-signature','unknown-signer','embedded-attacker-key','apollo-only','arm64-only','missing-platform','missing-architecture','signed-hash-mismatch','signed-app-identity-mismatch','metadata-tampering'):
        try:verify(fixtures/(name+'.napp'))
        except Exception as error:tests.append({'case':name,'rejected':True,'reason':str(error)})
        else:tests.append({'case':name,'rejected':False})
    with tempfile.TemporaryDirectory(prefix='gemini-games-public-only-negative-') as temp:
        with zipfile.ZipFile(package) as archive:original={n:archive.read(n) for n in archive.namelist()}
        for name in ('game-unsigned','game-modified-manifest','game-modified-payload','game-bad-signature','game-embedded-key'):
            items=dict(original)
            if name=='game-unsigned':items.pop('manifest.json.sig')
            if name=='game-modified-manifest':items['manifest.json']+=b' '
            if name=='game-modified-payload':items['payload/qml/apps/gemini-games/Main.qml']+=b'// tampered\n'
            if name=='game-bad-signature':items['manifest.json.sig']=b'invalid'
            if name=='game-embedded-key':items['public-key.gpg']=KEY.read_bytes()
            path=Path(temp)/(name+'.napp')
            with zipfile.ZipFile(path,'w') as archive:
                for member,data in items.items():archive.writestr(member,data)
            try:verify(path)
            except Exception as error:tests.append({'case':name,'rejected':True,'reason':str(error)})
            else:tests.append({'case':name,'rejected':False})
        try:verify(package,expected_sha='0'*64)
        except Exception as error:tests.append({'case':'catalog-package-hash-mismatch','rejected':True,'reason':str(error)})
        else:tests.append({'case':'catalog-package-hash-mismatch','rejected':False})
    assert all(t['rejected'] for t in tests)
    public={k:v for k,v in result.items() if k!='manifest'}
    report={'success':True,'package':public,'catalogSigner':identity['fingerprint'],'signedPlatformArchitectureVerified':True,'everyFileHashVerified':True,
            'negativeTests':tests,'archiveInspectorAccepted':True,'requiresPrivilegedBoundary':True,'offlinePublicKeyOwnerException':True,
            'productionTrustEnforcementChanged':False,'actualPrivilegedInstallationTested':False,'actualUpdateTested':False,'actualRemovalTested':False,
            'userDataRemovalDeclared':False,'versionComparisonTested':True}
    (W/'validation/package-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f"Signed Gemini NAPP accepted: {result['files']} hashes; {len(tests)} rejection tests passed. Privileged install/update/removal remain untested.")

if __name__=='__main__':main()
