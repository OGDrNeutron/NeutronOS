#include "GeminiGamesBackend.h"
#include "../source/src/HumanAccountPolicy.h"
#include <QTest>
#include <QSignalSpy>
#include <QImage>
#include <QFile>
#include <QDir>
using namespace GeminiGames;
class AccountTests:public QObject {
    Q_OBJECT
private slots:
    void accountSwitch() {
        // OS passwd/home fixtures are bound only inside the isolated test process.
        // Production identity resolution and backend code are used unchanged.
        const QString first="games_fixture_a",second="games_fixture_b";
        qInfo()<<"Validated fixture policy:"<<HumanAccountPolicy::namedUserIsHuman(first)
               <<QFileInfo("/NeutronOS/"+first).isDir()<<HumanAccountPolicy::uidRange().minimum<<HumanAccountPolicy::uidRange().maximum;
        QVERIFY(!HumanHome::forUser(first).isEmpty());
        QVERIFY(!HumanHome::forUser(second).isEmpty());
        HumanHome::setSessionUser(first);
        GeminiGamesBackend backend;QVERIFY(backend.initialize());
        backend.setSystemAccess(true);
        const QString originalDirectory=backend.artworkDirectory();
        QImage cover(50,60,QImage::Format_RGB32);cover.fill(Qt::red);
        QVERIFY(cover.save(originalDirectory+"/Private Game.png"));backend.refreshArtwork();
        QTRY_COMPARE_WITH_TIMEOUT(backend.artworkFiles().size(),1,10000);
        QVERIFY(backend.setPreference("animations",false));
        backend.setUiState({{"page",3}});backend.notify("Private account message",true);
        QCOMPARE(backend.messages().last().toMap().value("text").toString(),QString("Private account message"));
        QSignalSpy notifications(&backend,&GeminiGamesBackend::messagePublished);
        HumanHome::setSessionUser(second);
        // Even before the QML identity-change notification, old personal data is hidden.
        QVERIFY(backend.games().isEmpty());QVERIFY(backend.roots().isEmpty());
        QVERIFY(backend.artworkFiles().isEmpty());QVERIFY(backend.artworkDirectory().isEmpty());
        QVERIFY(backend.preferences().isEmpty());QVERIFY(backend.messages().isEmpty());
        QVERIFY(backend.uiState().isEmpty());QVERIFY(backend.logPath().isEmpty());
        QVERIFY(!backend.setPreference("animations",true));
        QVERIFY(!backend.addFolder("/tmp"));QVERIFY(!backend.removeFolder(0));
        QVERIFY(!backend.setArtworkAssignment("any",originalDirectory+"/Private Game.png"));
        backend.notify("Previous-session callback",true);QCOMPARE(notifications.size(),0);
        backend.accountChanged();
        QCOMPARE(backend.artworkDirectory(),HumanHome::forUser(second)+"/apps/gemini-games/artwork");
        QVERIFY(backend.artworkFiles().isEmpty());QVERIFY(backend.preferences().isEmpty());
        QVERIFY(backend.uiState().isEmpty());QVERIFY(backend.messages().isEmpty());
        QVERIFY(!backend.setArtworkAssignment("any",originalDirectory+"/Private Game.png"));
        HumanHome::setSessionUser(first);backend.accountChanged();
        QCOMPARE(backend.artworkDirectory(),originalDirectory);
        QCOMPARE(backend.preferences().value("animations").toBool(),false);
        QCOMPARE(backend.uiState().value("page").toInt(),3);
        QTRY_COMPARE_WITH_TIMEOUT(backend.artworkFiles().size(),1,10000);
        HumanHome::setSessionUser("nonexistent_games_user");backend.accountChanged();
        QVERIFY(backend.artworkFiles().isEmpty());QVERIFY(backend.roots().isEmpty());
        QVERIFY(!backend.setPreference("animations",true));
        QVERIFY(QFileInfo::exists(originalDirectory+"/Private Game.png"));
        HumanHome::setSessionUser("");
    }
};
QTEST_GUILESS_MAIN(AccountTests)
#include "account_isolation.moc"
