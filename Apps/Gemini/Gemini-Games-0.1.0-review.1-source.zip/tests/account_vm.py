#!/usr/bin/python3
"""Real Qt/account API test in a disposable guest's private mount namespace."""
import os,shutil,subprocess,tempfile
from pathlib import Path
W=Path(__file__).resolve().parents[1]
if W!=Path('/tmp/gemini-games-review') or os.geteuid()!=0:
    raise SystemExit('Run only in the existing disposable guest test directory')
with tempfile.TemporaryDirectory(prefix='account-fixtures-',dir=W) as temp:
    fixture=Path(temp)
    passwd=Path('/etc/passwd').read_text().rstrip()+'\n'
    for number,name in enumerate(('games_fixture_a','games_fixture_b'),59001):
        (fixture/'NeutronOS'/name).mkdir(parents=True)
        (fixture/'NeutronOS'/name/'Games').mkdir()
        passwd+=f'{name}:x:{number}:{number}:Games isolated fixture:/NeutronOS/{name}:/bin/bash\n'
    (fixture/'passwd').write_text(passwd)
    command=['bwrap','--unshare-all','--ro-bind','/','/','--dev','/dev','--proc','/proc','--bind',str(fixture),str(fixture),'--bind',str(fixture/'NeutronOS'),'/NeutronOS','--ro-bind',str(fixture/'passwd'),'/etc/passwd','--',str(W/'build-tests/games-account-tests'),'-o',str(fixture/'account-tests.xml')+',xml','-o',str(fixture/'account-tests.txt')+',txt']
    result=subprocess.run(command)
    for name in ('account-tests.xml','account-tests.txt'):
        if (fixture/name).exists():shutil.copyfile(fixture/name,W/'validation'/name)
    print((W/'validation/account-tests.txt').read_text())
    raise SystemExit(result.returncode)
