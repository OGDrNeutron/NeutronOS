import QtQuick
import QtQuick.Window
import "../source/qml/apps/gemini-games" as Games
Window {
    width: 1672
    height: 941
    visible: true
    color: "black"
    Games.Main { backend: testBackend }
    Games.GameMenu { objectName: "GameMenuValidation"; anchors.fill: parent; session: testBackend }
}
