#!/usr/bin/python3
"""Verify the signed Games artifact through installed Gemini CLI/root boundary.

Does not invoke install, rebuild, update or removal, and changes no trust files.
"""
from pathlib import Path
import hashlib,json,runpy,shutil,subprocess,sys,tempfile
package=Path(sys.argv[1]);expected=sys.argv[2]
assert hashlib.sha256(package.read_bytes()).hexdigest()==expected
helper=runpy.run_path('/usr/local/libexec/neutronos-privileged-helper.real',run_name='games_validation')
result=subprocess.run(['/usr/local/libexec/neutronos-napp-verify','verify',str(package),'--expected-sha',expected,'--expected-id','gemini-games','--expected-version','0.1.0-review.1'],capture_output=True,text=True,timeout=30)
assert result.returncode==0,result.stderr
cli=json.loads(result.stdout)
stage=Path('/run/neutronos-appstore-guard');stage.mkdir(mode=0o700,exist_ok=True);assert stage.stat().st_uid==0 and not stage.stat().st_mode&0o077
with tempfile.NamedTemporaryFile(prefix='games-review-',suffix='.napp',dir=stage) as snapshot:
 shutil.copyfile(package,snapshot.name);Path(snapshot.name).chmod(0o600)
 verified,manifest=helper['verify_signed_napp'](snapshot.name,expected,'gemini-games')
 checks={'installedCliAcceptsSignedGames':True,'expectedReleaseIdentity':cli['signer']=='F1A1E10BD2DB35060D6E61187CEB773D5ABD64B0','privilegedBoundaryReverifiesGames':True,'signedGeminiCompatibility':manifest['platforms']==['gemini'],'signedAmd64Compatibility':manifest['architectures']==['amd64'],'allSignedFilesVerified':cli['files']==len(manifest['fileHashes']),'nativeBuildOwnershipAccepted':helper['validate_rebuild_manifest'](manifest,'gemini-games'),'noUserDataDeletion':manifest['uninstallState']==[]}
report={'passed':all(checks.values()),'checks':checks,'packageSha256':expected,'verifier':cli,'actualInstall':False,'actualUpdate':False,'actualRemoval':False,'productionTrustChanged':False}
out=Path('/tmp/gemini-games-review/validation/installed-games-package.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'checks':len(checks)}));raise SystemExit(0 if report['passed'] else 1)
