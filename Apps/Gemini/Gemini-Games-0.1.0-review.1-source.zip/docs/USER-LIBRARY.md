# Authorized existing library inspection

Testing root: /NeutronMedia/Games/. The account's default Games directory is
unchanged; this is an additional test root with state in a temporary isolated
workspace. No game file was modified, moved, renamed or extracted.

| Candidate | Read-only evidence | Status |
|---|---|---|
| New Super Mario Bros. Wii | Valid 7z container; trusted 7-Zip list-only inspection finds a .nkit.iso member | Extracted data and verified Dolphin/NKit compatibility required; no launch attempted |
| Stray | ZIP central-directory inspection finds Windows/Win64 executables | Archive requires extracted Windows files and verified runtime/title support |
| Breath of the Wild | Outer ZIP contains nested Game Files.zip and an older cemu_1.12.0.zip | Contents of nested game data and suitable current native Cemu remain unverified |
| Plutonium T6 directories | Data folders and redistributable installers; no T6 executable or Plutonium launcher found | Incomplete launch data; not advertised as ready to play |

The native production GameLibrary probe discovers the three archives, marks
them as requiring extraction, and rejects all direct launch recommendations.
Manually choosing Wii cannot bypass the backend archive guard. A repeat scan
keeps the entry count stable; removing the additional root leaves original
files present. Redistributable EXEs are not offered as games.

The original test snapshot contains 699 files totaling 40,027,926,208 bytes. Before/after
checks compare size, modification/change timestamps and first/last 64 KiB
samples. These are read-only preservation checks, not full-file authenticity
hashes. Archive contents were listed as metadata; no game or emulator ran.

Per the user's test arrangement, the Sony controller belongs to the physical
development PC and will not be attached, detached or reconfigured here.
Physical passthrough, analog hardware behavior, fullscreen gameplay, global
PS/Home long-press, game-session restoration and multiplayer remain pending
physical acceptance. Those tests need the reviewed Games OS integration; the
separate support patch has not altered the preserved 0.5.4 release image.


The final check found seven additional files in `It.Takes.Two-CODEX/`, including
`codex-it.takes.two.iso`. These were not present in the initial snapshot and
are reported separately; all 699 original files remain unchanged. A targeted
read-only production scan now recognizes the ISO's BEA01/NSR02/TEA01 volume
recognition sequence as an unverified disc container (`archiveFormat=udf-disc`).
It requires user-authorized mounting/extraction and verified game files/runtime;
no emulator is inferred from `.iso` alone. No mounting, extraction or launch
was attempted. `validation/user-library-added-candidate.json` records stable
rescanning, safe root removal and the blocked direct-launch recommendation.
