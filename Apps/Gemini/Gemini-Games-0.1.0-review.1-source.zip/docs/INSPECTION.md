# Inspected architecture and change contract

Baseline: OGDrNeutron/NeutronOS local repository /tmp/gemini-054-publication,
HEAD 86a8e65fac9a1499e41ec9b644d7efff9c0a9aa0 (Gemini catalog publication).
This repository holds Apps, not the current full OS source. Current Gemini
implementation is /NeutronMedia/NeutronOS-Gemini/revisions/0.5.4/source;
base /NeutronMedia/NeutronOS-Gemini/source predates the GPG NAPP migration.
All implementation is in this isolated Gemini workspace; originals are read-only.

| Requested inspection | Actual source / behavior |
|---|---|
| Apollo Games | Repository Apps/Games-1.1.1.Napp payload/qml/apps/games is the available UI source; retained Apollo working/reconciled source has GamesManager but no Games QML directory |
| Apollo Games backend | src/GamesManager.{h,cpp}; Gemini inherited a copy but new app must not depend on it |
| Supervisor | scripts/neutronos-game-supervisor.py, neutronos-game-runtime.sh; Settings hold ends runtime and resume relaunches |
| Display handoff | supervisor SIGSTOP/SIGCONT of neutronos.service; shared Weston wayland-0; service /run/neutronos-compositor |
| Controller | src/ControllerManager.{h,cpp}, input EV_KEY BTN_MODE maps home; scripts/neutronos-controller-transport.py; qml/Main.qml central routing |
| Running applications | AppManager.runningApps/runtimeState/focusRuntime; real QML lifecycle and external process/service/tab state |
| Gemini applications | qml/apps/<id>/Main.qml and app.json; AppHost filesystem Loader; package overlays under human apps/payload |
| NAPP format | config/app-store/PACKAGE_FORMAT.md; schema 1 ZIP signed manifest, payload, declarative buildFiles and systemFiles |
| Store | AppStoreManager.{h,cpp}, qml/apps/appstore, scripts/neutronos-appstore-package.py; authenticated catalog and transactional install |
| Catalog | Apps/Gemini/index.json, schema 1 repository/packages; platforms, architectures, packageUrl, sha256 |
| Lifecycle | qml/apps/AppHost.qml onAppClosing/onAppBackgrounding; background unloads QML; app-owned durable state required |
| Qt/modules | CMake Qt6 >=6.2 Core Concurrent DBus Gui Network Qml Quick WebSockets WebEngineQuick; retained Debian13 build root contains Qt 6.8.2 |
| Wine/Proton | inherited GamesManager executable/runtime detection; no independently authenticated Gemini managed Wine/Proton provisioning contract |
| Emulators | inherited GamesManager RetroArch/Cemu/Dolphin/PPSSPP options; must probe actual installed programs for new app |
| Removable media | StorageManager.devices/deviceDetails/refreshDevices and mount/eject guarded APIs; filesystem watchers must retain disconnected entries |
| Accounts/storage | HumanAccountPolicy.h HumanHome.path/forUser validates passwd /NeutronOS/<username>; app state below <home>/apps/<id> |
| Notifications | NotificationManager.publish/markRead/dismiss persisted history; controller routing already exists |
| Performance | inherited PerformanceManager and PowerModeManager include Pi frequency assumptions; unsafe to reuse those for PC clocks |
| Termination | inherited process-group signals and supervisor; new child ownership must avoid unrelated process IDs and offer force close after timeout |
| Privilege | dedicated neutronos display account; privileged-helper guard, appstore root broker and immutable NAPP snapshots; no generic unsigned install |
| Switching/session | AppManager runtimeFocusRequested consumed in Main only from Console; Games-scoped routing needed to switch directly from app |

## Plan / invariants

1. Build package-owned scanner/index and conservative recommendations, with real header/structure fixtures.
2. Build native QML navigation, footer, setup dialogs and settings over the backend.
3. Add only Gemini Games conditional controller/session/switching seams; owned process lifecycle and reversible UI quiescence.
4. Compile and run scanner/lifecycle/QML tests; record hardware limitations and actual measured process resources.
5. Assemble and verify using existing GPG verifier, stage catalog change separately, validate Apollo hashes.

ID gemini-games; state <validated-human-home>/apps/gemini-games; games
<validated-human-home>/Games. No delete/move/rename of library files. No Apollo
edits, no live catalog edits, no publication, no automatic dependency installation.
Highest risks: filesystem disconnect races, scan/write races, process ownership,
controller release/disconnect timing, real compositor activation, package signing,
and app unload during game execution. Completion requires execution evidence;
unsupported/unverified capabilities must stay visible rather than be represented
as playable. Hardware GPU clocks are read-only and no PC overclock is offered.
