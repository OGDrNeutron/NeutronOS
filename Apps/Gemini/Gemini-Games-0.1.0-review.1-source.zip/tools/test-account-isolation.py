#!/usr/bin/env python3
"""Run account fixtures in the existing disposable VM; never change real accounts."""
from pathlib import Path
import subprocess, sys, tarfile
W=Path(__file__).resolve().parents[1]
transfer=W/'staging/vm-transfer/account-tests.tar.gz'
with tarfile.open(transfer,'w:gz') as archive:
    for member in ('tests/account_vm.py','build-tests/games-account-tests'):
        archive.add(W/member,arcname=member)
control=[sys.executable,str(W/'tools/vm-control.py'),'exec']
command='curl -fsS http://10.0.2.2:22564/account-tests.tar.gz | tar -xzf - -C /tmp/gemini-games-review; python3 /tmp/gemini-games-review/tests/account_vm.py'
result=subprocess.run(control+[command])
for name in ('account-tests.xml','account-tests.txt'):
    with (W/'validation'/name).open('w') as out:
        fetch=subprocess.run(control+['cat /tmp/gemini-games-review/validation/'+name],stdout=out)
        if fetch.returncode:raise SystemExit(fetch.returncode)
raise SystemExit(result.returncode)
