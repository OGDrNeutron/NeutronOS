#!/usr/bin/env python3
"""Use the existing external OpenPGP process for explicit local review signing."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, tempfile, zipfile

W=Path(__file__).resolve().parents[1]
F='F1A1E10BD2DB35060D6E61187CEB773D5ABD64B0'
IDENTITY='NeutronOS Release Signing <OGDrNeutron@proton.me>'
KEY=Path('/NeutronMedia/OS Sign Key.txt')

def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def sign():
    # Private material is confined to memory and an external temporary GnuPG home.
    # It never enters the workspace, package inputs, source/build archives, or logs.
    if not KEY.is_file(): raise RuntimeError('External signing key is missing at /NeutronMedia/OS Sign Key.txt')
    with tempfile.TemporaryDirectory(prefix='neutronos-games-external-signing-',dir='/tmp') as temp:
        home=Path(temp);os.chmod(home,0o700)
        def gpg(args,data=None):
            result=subprocess.run(['gpg','--batch','--no-options','--homedir',str(home),'--pinentry-mode','loopback',*args],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
            if result.returncode: raise RuntimeError('External GnuPG operation failed; private diagnostics suppressed')
            return result.stdout
        try:
            public=gpg(['--import-options','show-only','--with-colons','--import'],KEY.read_bytes()).decode().splitlines()
            fprs=[r.split(':')[9] for r in public if r.startswith('fpr:')]
            uids=[r.split(':')[9] for r in public if r.startswith('uid:')]
            if not fprs or fprs[0]!=F or IDENTITY not in uids: raise RuntimeError('External signing identity/fingerprint does not match the required NeutronOS release identity')
            dump(W/'validation/signing-identity.json',{'available':True,'expectedFingerprint':F,'fingerprints':fprs,'identities':uids,'matches':True,'privateMaterialPrinted':False})
            gpg(['--import'],KEY.read_bytes())
            def detached(data): return gpg(['--local-user',F,'--passphrase','','--detach-sign','--output','-'],data)
            root=W/'staging/package-input';manifest=json.loads((root/'manifest.json').read_text())
            # Refuse stale or undeclared inputs before creating any signature.
            members={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'manifest.json'}
            if members!=set(manifest['fileHashes']): raise RuntimeError('Package input file set differs from the manifest')
            for name,expected in manifest['fileHashes'].items():
                if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Package input changed after preparation')
            raw=(root/'manifest.json').read_bytes();signature=detached(raw)
            out=W/'Apps/Gemini';out.mkdir(parents=True,exist_ok=True)
            package=out/f"Gemini-Games-{manifest['version']}.napp"
            with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
                archive.writestr('manifest.json',raw);archive.writestr('manifest.json.sig',signature)
                executable={entry['source'] for entry in manifest['systemFiles'] if entry['mode']=='0755'}
                for name in sorted(manifest['fileHashes']):
                    info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED
                    info.external_attr=(0o100755 if name in executable else 0o100644)<<16
                    archive.writestr(info,(root/name).read_bytes())
            entry={key:manifest[key] for key in ('id','name','version','description','platforms','architectures','permissions','debianDependencies')}
            entry.update(developer='NeutronOS',category='Games',minNeutronOS='0.5.4',packageUrl=package.name,sha256=hashlib.sha256(package.read_bytes()).hexdigest(),size=package.stat().st_size,
                         installedBytes=sum((root/name).stat().st_size for name in manifest['fileHashes']),
                         dependencies=['Reviewed Gemini Games OS session integration (separate patch)','Python 3 and bubblewrap; controller ownership service','Optional installed game runtimes require per-game setup and real session validation'],
                         icon='icons/gemini-games.png',poster='posters/gemini-games.png',changelogUrl='https://raw.githubusercontent.com/OGDrNeutron/NeutronOS/main/Apps/Gemini/changelogs/gemini-games-0.1.0-review.1.md',requiresDeveloperMode=False)
            stage=W/'staging/repository/Apps/Gemini';stage.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(package,stage/package.name)
            baseline=json.loads((W/'catalog-baseline/index.json').read_text())
            if any(p.get('id')==manifest['id'] for p in baseline['packages']):raise RuntimeError('Catalog already has a Games entry; review update merge explicitly')
            baseline['packages'].append(entry);dump(stage/'index.json',baseline)
            (stage/'index.json.sig').write_bytes(detached((stage/'index.json').read_bytes()))
            dump(out/'gemini-games.catalog-entry.json',entry)
            for folder in ('icons','posters'):
                p=stage/folder;p.mkdir(exist_ok=True);(p/'gemini-games.png').write_bytes((W/'validation/gemini-games.png').read_bytes())
            dump(W/'validation/signing-process.json',{'signer':F,'algorithm':'OpenPGP','signedFiles':['internal manifest','staged Gemini index.json'],'externalTemporaryHomeRemoved':True,'privateKeyInArtifacts':False,'published':False,'releaseReadiness':'blocked pending actual game/controller/compositor validation'})
        finally:
            subprocess.run(['gpgconf','--homedir',str(home),'--kill','gpg-agent'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    print('Signed local Gemini review NAPP and staged catalog; nothing published.')

if __name__=='__main__':
    try:sign()
    except (OSError,RuntimeError,subprocess.SubprocessError) as error:
        dump(W/'validation/signing-blocker.json',{'blocked':True,'reason':str(error),'privateDiagnosticsSuppressed':True})
        raise SystemExit(str(error))
