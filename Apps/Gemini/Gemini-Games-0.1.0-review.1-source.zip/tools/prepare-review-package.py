#!/usr/bin/env python3
"""Prepare only local Gemini review inputs; never sign or publish implicitly."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, zipfile

W = Path(__file__).resolve().parents[1]
S = W / 'source'
ID = 'gemini-games'
VERSION = '0.1.0-review.1'

def digest(data): return hashlib.sha256(data).hexdigest()
def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def prepare():
    files = {}
    for path in sorted((S / f'qml/apps/{ID}').iterdir()):
        if path.is_file(): files[f'payload/qml/apps/{ID}/{path.name}'] = path.read_bytes()
    icon = (W/'validation/gemini-games.png').read_bytes()
    for folder in ('icons', 'posters'): files[f'payload/themes/Default/apps/{folder}/{ID}.png'] = icon
    build = []
    for path in sorted((S/f'src/package_apps/{ID}').iterdir()):
        if path.suffix not in ('.h','.cpp'): continue
        member = f'build/owned/{path.name}'
        files[member] = path.read_bytes()
        build.append({'source':member,'destination':f'src/package_apps/{ID}/{path.name}','mode':'0644'})
    system = []
    for source, destination, executable, enable in (
        (S/f'scripts/apps/{ID}/controller_proxy.py',f'/usr/local/lib/neutronos/{ID}/controller_proxy.py',True,False),
        (W/'package-system/neutronos-gemini-game-input.service','/etc/systemd/system/neutronos-gemini-game-input.service',False,True)):
        member = 'system/owned'+destination
        files[member] = source.read_bytes()
        system.append({'source':member,'destination':destination,'ownership':'package','mode':'0755' if executable else '0644','enableNow':enable})
    app = json.loads((S/f'qml/apps/{ID}/app.json').read_text())
    manifest = {key:app[key] for key in ('id','version','name','description','permissions','platforms','architectures')}
    manifest.update(schema=1, uninstallState=[], debianDependencies=['python3','bubblewrap'], systemFiles=system, buildFiles=build, rebuildRequired=True,
                    fileHashes={name:digest(data) for name,data in files.items()})
    spec = importlib.util.spec_from_file_location('current_package_helper',S/'scripts/neutronos-appstore-package.py')
    helper = importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.validate_manifest(dict(manifest))
    out = W/'staging/package-input'
    out.mkdir(parents=True,exist_ok=True)
    dump(out/'manifest.json',manifest)
    for name,data in files.items():
        path = out/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    dump(W/'validation/package-input.json',{'id':ID,'version':VERSION,'files':len(files),'privateMaterialIncluded':False,'publicationAuthorized':False,'requiresReviewedOsSessionPatch':True})
    print(f'Prepared {len(files)} signed-manifest inputs for local review; no signing or publication performed.')

if __name__ == '__main__': prepare()
