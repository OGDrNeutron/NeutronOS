#!/usr/bin/env python3
"""Read the disposable Games VM and use its existing private test console."""
from pathlib import Path
import argparse,base64,json,secrets,socket,time
V=Path(__file__).resolve().parents[1]/'validation/games-vm'
def qmp(command,arguments=None):
    with socket.socket(socket.AF_UNIX) as sock:
        sock.settimeout(10);sock.connect(str(V/'qmp.sock'));f=sock.makefile('rb');json.loads(f.readline())
        for name,args in [('qmp_capabilities',None),(command,arguments)]:
            msg={'execute':name}
            if args:msg['arguments']=args
            sock.sendall(json.dumps(msg).encode()+b'\n')
            while True:
                reply=json.loads(f.readline())
                if 'return' in reply:break
                if 'error' in reply:raise RuntimeError(reply['error'])
        return reply['return']
def execute(command):
    token=secrets.token_hex(6);encoded=base64.b64encode(command.encode()).decode()
    line=f"printf '\\nGAMES_BEGIN_{token}\\n'; printf '%s' '{encoded}' | base64 -d | env SYSTEMD_PAGER=cat SYSTEMD_COLORS=0 PAGER=cat TERM=dumb bash; games_rc=$?; printf '\\nGAMES_END_{token}:%s\\n' \"$games_rc\"\n"
    output=b''
    with socket.socket(socket.AF_UNIX) as sock:
        sock.settimeout(.5);sock.connect(str(V/'debug.sock'))
        sock.sendall(line.encode());deadline=time.monotonic()+45
        start=('GAMES_BEGIN_'+token+'\r\n').encode();end=('GAMES_END_'+token+':').encode()
        while time.monotonic()<deadline:
            try:data=sock.recv(65536)
            except socket.timeout:continue
            if not data:break
            output+=data
            # Match actual line markers, not the terminal's echoed command.
            output=output.replace(b'\r',b'')
            start=('GAMES_BEGIN_'+token+'\n').encode()
            marker=output.find(start)
            if marker<0:start=('GAMES_BEGIN_'+token+'\n').encode();marker=output.find(start)
            position=output.find(end,marker+len(start)) if marker>=0 else -1
            if position>=0 and b'\n' in output[position:]:
                text=output[marker+len(start):position].decode(errors='replace').replace('\r','')
                status=int(output[position+len(end):].splitlines()[0].strip())
                print(text,end='');return status
    (V/'guest-console-last.log').write_bytes(output)
    raise RuntimeError('Private guest test console has not responded; VM state preserved')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['status','capture','exec']);p.add_argument('value',nargs='?');a=p.parse_args()
    for name in ('qmp.sock','serial.sock','debug.sock','display.sock'):
        path=V/name
        if path.exists():path.chmod(0o600)
    if a.action=='exec':raise SystemExit(execute(a.value or 'true'))
    elif a.action=='capture':
        target=(V/(a.value or 'display.png')).with_suffix('.png');qmp('screendump',{'filename':str(target),'format':'png'})
        try:
            from PIL import Image
            image=Image.open(target);image.save(target.with_suffix('.png'));print(target.with_suffix('.png'))
        except ImportError:print(target)
    else:print(json.dumps({'status':qmp('query-status'),'blockDevices':qmp('query-block')},indent=2))
