#!/usr/bin/env python3
"""Read-only comparison with the recorded user game-library snapshot."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parents[1]
before=json.loads((W/'validation/user-games-before.json').read_text())
root=Path(before['root']);expected={r['path']:r for r in before['files']}
actual={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file() and not p.is_symlink()}
mismatches=[];additions=sorted(actual.keys()-expected.keys())
for name in sorted(expected):
    if name not in actual:
        mismatches.append({'path':name,'reason':'file set changed'});continue
    p=actual[name];stat=p.stat()
    with p.open('rb') as f:
        head=f.read(65536);f.seek(max(0,stat.st_size-65536));tail=f.read(65536)
    after={'path':name,'bytes':stat.st_size,'mtimeNs':stat.st_mtime_ns,'ctimeNs':stat.st_ctime_ns,'sampleSha256':hashlib.sha256(head+tail+str(stat.st_size).encode()).hexdigest()}
    if after!=expected[name]:mismatches.append({'path':name,'reason':'metadata or sampled content changed'})
report={'root':str(root),'filesChecked':len(expected),'unchanged':not mismatches,'mismatches':mismatches,'additionalFilesNotInOriginalSnapshot':additions,'fileSetUnchanged':not additions and not mismatches,'check':'Original recorded files: size, modification/change timestamps and sampled first/last 64 KiB hash plus size; not full-content hashes','gameFilesWritten':False,'gameFilesExtracted':False}
(W/'validation/user-games-preservation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f"Read-only preservation: {len(expected)} files; unchanged={report['unchanged']}")
raise SystemExit(0 if report['unchanged'] else 1)
