#!/usr/bin/env python3
"""Boot a persistent local COW test VM; preserved Gemini drives stay read-only."""
from pathlib import Path
import json,os,shutil,socket,subprocess
W=Path(__file__).resolve().parents[1];V=W/'validation/games-vm';B=Path('/NeutronMedia/NeutronOS-Gemini/revisions/0.5.4');H=B/'build/host-tools';ROOT=B/'staging/debian-base'
V.mkdir(exist_ok=True)
if (V/'pid').exists():
    try:
        os.kill(int((V/'pid').read_text()),0)
        raise SystemExit('Review VM is already running; preserve it and continue through its existing sockets')
    except ProcessLookupError:pass
base=B/'validation/vm-final-ssh-enabled-reboot/test-drive.img'
env=dict(os.environ,LD_LIBRARY_PATH=str(H/'usr/lib/x86_64-linux-gnu'),QEMU_MODULE_DIR=str(H/'usr/lib/x86_64-linux-gnu/qemu'))
overlay=V/'games.qcow2'
if not overlay.exists():
    createenv=dict(os.environ,LD_LIBRARY_PATH=str(ROOT/'usr/lib/x86_64-linux-gnu'))
    subprocess.run([str(ROOT/'usr/bin/qemu-img'),'create','-f','qcow2','-F','raw','-b',str(base),str(overlay)],env=createenv,check=True)
vars=V/'OVMF_VARS.fd'
if not vars.exists():shutil.copyfile(base.parent/'OVMF_VARS.fd',vars)
for name in ('qmp.sock','serial.sock','debug.sock','display.sock'):
    path=V/name
    if path.exists():
        try:
            s=socket.socket(socket.AF_UNIX);s.settimeout(.5);s.connect(str(path));s.close()
            raise SystemExit('Active VM socket exists; refuse replacing it')
        except (ConnectionRefusedError,FileNotFoundError):path.unlink()
accel='kvm' if os.access('/dev/kvm',os.R_OK|os.W_OK) else 'tcg,thread=multi'
args=[str(H/'usr/bin/qemu-system-x86_64'),'-L',str(H/'usr/share/qemu'),'-machine','q35,smm=on','-global','driver=cfi.pflash01,property=secure,value=on','-accel',accel,'-cpu','host' if accel=='kvm' else 'max','-smp','4','-m','4096',
      '-drive',f'if=pflash,format=raw,readonly=on,file={H}/usr/share/OVMF/OVMF_CODE_4M.ms.fd','-drive',f'if=pflash,format=raw,file={vars}',
      '-drive',f'if=virtio,format=qcow2,file={overlay}',
      '-vga','none','-device',f'virtio-vga,xres=1672,yres=941,romfile={H}/usr/share/seabios/vgabios-virtio.bin',
      '-device','qemu-xhci','-device','usb-kbd','-device','usb-tablet','-netdev','user,id=net0,hostfwd=tcp:127.0.0.1:22563-:22','-device','virtio-net-pci,netdev=net0,romfile=',
      '-audiodev','none,id=nosound','-device','intel-hda','-device','hda-duplex,audiodev=nosound',
      '-display','vnc=unix:'+str(V/'display.sock'),'-chardev',f'socket,id=serial,path={V}/serial.sock,server=on,wait=off','-serial','chardev:serial',
      '-chardev',f'socket,id=private,path={V}/debug.sock,server=on,wait=off','-serial','chardev:private','-qmp','unix:'+str(V/'qmp.sock')+',server=on,wait=off']
log=(V/'qemu.log').open('ab');process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(V/'pid').write_text(str(process.pid))
(V/'provenance.json').write_text(json.dumps({'readOnlyBackingDrive':str(base),'writeTarget':str(overlay),'sourceImageModified':False,'acceleration':accel,'signedUefiFirmwarePreserved':True,'displaySocket':str(V/'display.sock'),'guestPrivateConsole':'Existing validation fixture retained; production security unchanged','physicalDiskWrites':False},indent=2)+'\n')
print('Started isolated Games VM with local VNC/QMP display:',process.pid)
