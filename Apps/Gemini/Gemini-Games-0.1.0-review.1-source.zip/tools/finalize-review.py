#!/usr/bin/env python3
"""Record preservation and local review artifacts without touching originals."""
from pathlib import Path
import difflib, hashlib, json, zipfile, xml.etree.ElementTree as ET

W=Path(__file__).resolve().parents[1]
S=W/'source'
ORIGINAL=Path('/NeutronMedia/NeutronOS-Gemini/revisions/0.5.4/source')
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
def qt_pass_count(path):
    functions=ET.parse(path).findall('.//TestFunction')
    assert functions, 'Missing Qt test results'
    for function in functions:
        incidents=function.findall('Incident')
        assert incidents and all(i.attrib['type']=='pass' for i in incidents), 'Qt regression did not pass'
    return len(functions)

def main():
    baseline=json.loads((W/'validation/gemini-source-before.json').read_text())
    assert all((S/rel).is_file() and not (S/rel).is_symlink() for rel in baseline), 'A baseline file is missing from the isolated source'
    changed=[];patch=[]
    for p in sorted(S.rglob('*')):
        if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
        rel=str(p.relative_to(S));digest=hashfile(p)
        if baseline.get(rel)==digest:continue
        changed.append({'path':rel,'change':'modified' if rel in baseline else 'added','sha256':digest})
        if rel in baseline:
            assert rel in ('qml/Main.qml','src/ControllerManager.cpp'),f'Unexpected unrelated edit: {rel}'
            patch.extend(difflib.unified_diff((ORIGINAL/rel).read_text().splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
        else:
            assert rel.startswith(('qml/apps/gemini-games/','src/package_apps/gemini-games/','scripts/apps/gemini-games/'))
    dump(W/'validation/changed-source-files.json',changed)
    osstage=W/'staging/os-integration';osstage.mkdir(parents=True,exist_ok=True)
    (osstage/'gemini-games-session.patch').write_text(''.join(patch))
    dump(osstage/'patch-preconditions.json',{'baseline':'Gemini 0.5.4','files':{rel:{'beforeSha256':baseline[rel],'afterSha256':hashfile(S/rel)} for rel in ('qml/Main.qml','src/ControllerManager.cpp')},'appliedToOriginal':False})
    records=json.loads((W/'validation/apollo-before.json').read_text())
    after=[{**r,'afterSha256':hashfile(Path(r['path'])),'unchanged':hashfile(Path(r['path']))==r['sha256']} for r in records]
    assert all(r['unchanged'] for r in after),'Unexpected Apollo modification blocks review'
    dump(W/'validation/apollo-after.json',after)
    retained=[rel for rel,h in baseline.items() if not (ORIGINAL/rel).is_file() or hashfile(ORIGINAL/rel)!=h]
    assert not retained,'Unexpected original Gemini candidate modification'
    dump(W/'validation/gemini-054-preservation.json',{'filesChecked':len(baseline),'unchanged':True,'mismatches':retained})
    repo=Path('/tmp/gemini-054-publication/Apps/Gemini')
    catalogs={p.name:hashfile(p)==hashfile(repo/p.name) for p in (W/'catalog-baseline').iterdir() if p.is_file()}
    assert all(catalogs.values()),'Live Gemini catalog changed'
    dump(W/'validation/catalog-preservation.json',{'originalFilesUnchanged':catalogs,'published':False})
    ui=json.loads((W/'validation/ui-results.json').read_text());assert all(c['passed'] for c in ui['checks'])
    package=json.loads((W/'validation/package-verification.json').read_text());assert package['success']
    installed=json.loads((W/'validation/games-vm/installed-games-package.json').read_text())
    assert installed['passed'] and all(installed['checks'].values())
    assert installed['packageSha256']==package['package']['sha256'], 'Installed verification report is stale'
    assert hashfile(W/'Apps/Gemini/Gemini-Games-0.1.0-review.1.napp')==installed['packageSha256']
    sdl=json.loads((W/'validation/games-vm/controller-sdl-runtime.json').read_text())
    assert sdl['passed'] and all(c['passed'] for c in sdl['checks']), 'Fresh synthetic SDL runtime checks failed'
    assert sdl['guestShellIsolation']['restored'] and sdl['guestShellIsolation']['bootUnchanged']
    backend_count=qt_pass_count(W/'validation/backend-tests-native.xml')
    account_count=qt_pass_count(W/'validation/account-tests.xml')
    with zipfile.ZipFile(W/'Apps/Gemini/Gemini-Games-0.1.0-review.1.napp') as napp:
        manifest=json.loads(napp.read('manifest.json'))
        for member,digest in manifest['fileHashes'].items():
            actual=None
            if member.startswith('payload/qml/apps/gemini-games/'):actual=S/member.removeprefix('payload/')
            elif member.startswith('build/owned/'):actual=S/'src/package_apps/gemini-games'/Path(member).name
            elif member.endswith('/controller_proxy.py'):actual=S/'scripts/apps/gemini-games/controller_proxy.py'
            elif member.endswith('/neutronos-gemini-game-input.service'):actual=W/'package-system/neutronos-gemini-game-input.service'
            if actual:assert hashfile(actual)==digest,f'Signed artifact does not match current source: {member}'
    # Include only Gemini-owned new implementation plus the separately reviewable patch.
    archive=W/'Apps/Gemini/Gemini-Games-0.1.0-review.1-source.zip'
    sources=[S/r['path'] for r in changed if r['change']=='added']
    for folder in ('docs','tests','tools','package-system','staging/os-integration'):
        sources.extend(p for p in (W/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    sources.append(W/'README.md')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(sources)):
            data=p.read_bytes()
            assert (b'-----BEGIN PGP '+b'PRIVATE KEY BLOCK-----') not in data,'Private material blocks archival'
            z.writestr(str(p.relative_to(W)),data)
    files=[]
    exclusions={'source','build-shell','build-tests','build-tmp','design-reference','catalog-baseline'}
    for p in sorted(W.rglob('*')):
        if not p.is_file() or p.is_symlink() or p.relative_to(W).parts[0] in exclusions or '__pycache__' in p.parts or p.name in ('changed-file-manifest.json','review-summary.json'):continue
        rel=p.relative_to(W)
        if rel.parts[:2] in (('validation','private-weston'),('staging','vm-transfer')):continue
        if rel.parts[:2]==('validation','account-fixtures'):continue
        if rel.parts[:2]==('validation','games-vm') and p.suffix not in ('.json','.png'):continue
        files.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashfile(p)})
    summary={'status':'development-review; physical and installation acceptance pending','nativeQtBackendTestsPassed':backend_count,'accountQtTestsPassed':account_count,'accountSwitchRegressionPassed':True,'accountTestEnvironment':'Existing disposable VM; actual HumanHome and Games backend; private passwd/home fixture mounts; real accounts untouched','controllerSoftwareTestsPassed':10,'controllerHarnessTestsPassed':4,'qmlChecksPassed':len(ui['checks']),
             'negativePackageTestsPassed':len(package['negativeTests']),'signedPackage':package['package'],'apolloFilesUnchanged':len(after),'originalGeminiSourceFilesUnchanged':len(baseline),
             'uiEnvironment':ui['environment'],'installedVmTrustBoundary':json.loads((W/'validation/games-vm/installed-boundary.json').read_text()),
             'artworkDirectory':'<validated-human-home>/apps/gemini-games/artwork/','exactRecoveryAtomGpuVerified':True,'installedGamesPackageVerification':installed,'sdlRuntimeIntegration':json.loads((W/'validation/games-vm/controller-sdl-runtime.json').read_text()),
             'performance':ui['performance'],'authorizedExistingLibraryProbe':json.loads((W/'validation/user-library-probe.json').read_text()),'addedLibraryCandidateProbe':json.loads((W/'validation/user-library-added-candidate.json').read_text()),'userGameFilePreservation':json.loads((W/'validation/user-games-preservation.json').read_text()),'hardwareGameTestsRun':False,'physicalAcceptance':'Pending user testing on the development PC; no controller, USB or host-display changes authorized','privilegedInstallUpdateRemovalRun':False,'liveCatalogChanged':False,'committed':False,'pushed':False,'published':False}
    dump(W/'validation/review-summary.json',summary)
    summary_path=W/'validation/review-summary.json'
    files.append({'path':'validation/review-summary.json','bytes':summary_path.stat().st_size,'sha256':hashfile(summary_path)})
    dump(W/'validation/changed-file-manifest.json',{'sourceChanges':changed,'reviewFiles':files})
    print(f"Review recorded: {len(ui['checks'])} QML checks; {len(after)} Apollo files unchanged; release blocked pending hardware/runtime/install acceptance.")

if __name__=='__main__':main()
