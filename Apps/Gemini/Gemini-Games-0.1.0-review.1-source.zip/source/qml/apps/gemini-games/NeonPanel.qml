import QtQuick
Item {
    id: panel
    property bool illuminated: false
    property color fill: "#e808111e"
    property real radius: 14
    Rectangle { anchors.fill: parent; anchors.margins: -8; radius: panel.radius+8; color: "transparent"; border.color: "#300053ff"; border.width: 9; visible: panel.illuminated }
    Rectangle { anchors.fill: parent; anchors.margins: -4; radius: panel.radius+4; color: "transparent"; border.color: "#790075ff"; border.width: 5; visible: panel.illuminated }
    Rectangle { anchors.fill: parent; radius: panel.radius; color: panel.fill; border.color: panel.illuminated ? "#87e4ff" : "#234259"; border.width: panel.illuminated ? 2 : 1 }
}
